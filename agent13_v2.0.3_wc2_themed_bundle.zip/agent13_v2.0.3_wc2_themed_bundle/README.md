# Agent 13 — v2.0.3 (WC2 Themed + Wallet Status + Reconnect)

This release adds:

1. **Themed Web3Modal** (Agent 13 brand): custom app name, description, and color theme.
2. **Wallet status chip** in the header (address + network), with copy address & disconnect.
3. **Reconnect persistence & session restore** for WalletConnect v2 and injected providers.

> Built on top of v2.0.2 (WC2 UI). Drop these files into your repo and rebuild.

## Quick start

1. Ensure your `.env` exposes a WalletConnect **Project ID** to the web app:  
   `VITE_WC_PROJECT_ID` (Vite) or `NEXT_PUBLIC_WC_PROJECT_ID` (Next).
2. Place a logo at `public/agent13-logo.svg` (optional; a fallback emoji is used otherwise).
3. Rebuild & run:
```bash
pnpm install
make release
docker compose -f ops/compose.yml up -d
make digests
```
4. Open the app; the header will show the **wallet chip**. Visit **/connect-wallet** to connect if not already.

## What changed
- **Web3Modal theming**: brand name, colors, and icon applied via a small wrapper around `@walletconnect/ethereum-provider` and the standalone modal.
- **Status chip**: shows a shortened address and chain name/ID; click to copy or disconnect.
- **Persistence**: session info saved to `localStorage` and auto-restored on reload; WalletConnect v2 provider re-initializes without showing a QR when possible.

## Files of interest
- `apps/web/src/lib/wc.ts` — WalletConnect v2 provider + theming + silent reconnect.
- `apps/web/src/lib/walletSession.ts` — tiny persistence layer (save/load/clear).
- `apps/web/src/components/HeaderWalletChip.tsx` — chip UI and interactions.
- `apps/web/src/pages/ConnectWalletPage.tsx` — updated to save session on connect & offer disconnect.
- `Makefile`, `ops/compose.yml` — version **2.0.3**.

## Notes
- Silent reconnection works when the WalletConnect session is still valid; otherwise the chip will show **Disconnected** until you connect again.
- The chip listens for provider `chainChanged` and `accountsChanged` to keep display in sync.
