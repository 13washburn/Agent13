import React, { useState } from 'react';
import { getWCProvider, readProjectId } from '../lib/wc';
import { saveSession } from '../lib/walletSession';

async function fetchNonce(){
  const r = await fetch('http://localhost:8081/auth/siwe/nonce');
  return r.json();
}

async function signSiweWithProvider(provider: any, setStatus: (s:string)=>void){
  const accounts = await provider.request({ method: 'eth_requestAccounts' });
  const addr = accounts[0];
  const domain = window.location.host;
  const statement = 'Sign in to Agent 13';
  const { nonce } = await fetchNonce();
  const idHex = await provider.request({ method: 'eth_chainId' });
  const chainId = Number(idHex);

  const message = `${domain} wants you to sign in with your Ethereum account:
${addr}

URI: ${window.location.origin}
Version: 1
Chain ID: ${chainId}
Nonce: ${nonce}
Issued At: ${new Date().toISOString()}
Statement: ${statement}`;

  const signature = await provider.request({ method: 'personal_sign', params: [message, addr] });
  const verifyRes = await fetch('http://localhost:8081/auth/siwe/verify',{ method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ message, signature }) });
  const out = await verifyRes.json();
  if (out.ok){
    saveSession({ type: provider?.wc ? 'wc' : 'injected', address: addr, chainId, timestamp: Date.now() });
  }
  setStatus(out.ok ? 'Signed in with wallet' : String(out.error||'error'));
}

export default function ConnectWalletPage(){
  const [status,setStatus]=useState('');

  async function signWithWC(){
    try{
      const projectId = readProjectId(); if(!projectId) throw new Error('Missing WalletConnect project id');
      const provider = await getWCProvider(projectId, [1], {
        appName: 'Agent 13', appDescription: 'Realtime Stage 2/4 markets copilot',
        accentColor: '#10b981', backgroundColor: '#0b0f13',
      });
      await signSiweWithProvider(provider, setStatus);
    }catch(e:any){ setStatus(String(e?.message || e)); }
  }

  async function signWithInjected(){
    try{
      // @ts-ignore
      const eth = window.ethereum; if(!eth) throw new Error('No EIP-1193 provider found.');
      await signSiweWithProvider(eth, setStatus);
    }catch(e:any){ setStatus(String(e?.message || e)); }
  }

  return (
    <div className="min-h-screen grid place-items-center p-6">
      <div className="w-[480px] border rounded-2xl p-6 bg-card/50">
        <h1 className="text-xl font-semibold mb-3">Connect Wallet</h1>
        <p className="text-sm text-muted-foreground mb-3">Use WalletConnect v2 (QR modal) or an injected EIP‑1193 provider to sign a SIWE message and authenticate.</p>
        <div className="grid gap-2">
          <button onClick={signWithWC} className="rounded-xl border px-3 py-2 hover:bg-muted/60">Connect with WalletConnect v2</button>
          <button onClick={signWithInjected} className="rounded-xl border px-3 py-2 hover:bg-muted/60">Use injected provider (MetaMask, etc.)</button>
        </div>
        <div className="text-xs mt-3">{status}</div>
      </div>
    </div>
  );
}
