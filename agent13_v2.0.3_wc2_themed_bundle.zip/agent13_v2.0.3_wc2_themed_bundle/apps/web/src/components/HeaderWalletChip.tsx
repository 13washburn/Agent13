import React, { useEffect, useMemo, useState } from 'react';
import { loadSession, saveSession, clearSession } from '../lib/walletSession';
import { readProjectId, tryReconnectWC, shorten } from '../lib/wc';

function chainLabel(chainId: number){
  switch(chainId){
    case 1: return 'Ethereum';
    case 8453: return 'Base';
    case 10: return 'OP';
    case 137: return 'Polygon';
    default: return `Chain ${chainId}`;
  }
}

export default function HeaderWalletChip(){
  const [status, setStatus] = useState<'disconnected'|'connecting'|'connected'>('connecting');
  const [address, setAddress] = useState<string | null>(null);
  const [chainId, setChainId] = useState<number | null>(null);
  const [provider, setProvider] = useState<any>(null);

  // On mount, try to restore a session
  useEffect(() => {
    (async () => {
      const pid = readProjectId();
      const cached = loadSession();
      if (cached?.type === 'wc' && pid){
        const p = await tryReconnectWC(pid);
        if (p){
          setProvider(p);
          setAddress(cached.address);
          setChainId(cached.chainId);
          setStatus('connected');
          wireProvider(p);
          return;
        }
      }
      if (cached?.type === 'injected'){
        // @ts-ignore
        const eth = (window as any).ethereum;
        if (eth){
          try {
            const accounts = await eth.request({ method: 'eth_accounts' });
            const id = await eth.request({ method: 'eth_chainId' });
            const cId = Number(id);
            if (accounts?.length){
              setProvider(eth);
              setAddress(accounts[0]);
              setChainId(cId);
              setStatus('connected');
              wireProvider(eth);
              return;
            }
          } catch {}
        }
      }
      setStatus('disconnected');
    })();
  }, []);

  function wireProvider(p: any){
    if (!p || p.__wired) return; p.__wired = true;
    p.on?.('accountsChanged', (accs: string[]) => {
      const a = accs?.[0] || null; setAddress(a);
      if (a && chainId!=null) saveSession({ type: provider?.wc ? 'wc':'injected', address:a, chainId, timestamp:Date.now() });
    });
    p.on?.('chainChanged', (id: string|number) => {
      const c = Number(id); setChainId(c);
      if (address) saveSession({ type: provider?.wc ? 'wc':'injected', address, chainId:c, timestamp:Date.now() });
    });
    p.on?.('disconnect', () => { setStatus('disconnected'); setAddress(null); setChainId(null); clearSession(); });
  }

  async function disconnect(){
    try { await provider?.disconnect?.(); } catch {}
    setStatus('disconnected'); setAddress(null); setChainId(null); clearSession();
  }

  async function copy(){ if (address) await navigator.clipboard.writeText(address); }

  const label = useMemo(() => {
    if (status==='connecting') return 'Connecting…';
    if (status==='disconnected') return 'Disconnected';
    return `${shorten(address||'')} • ${chainLabel(chainId||0)}`;
  }, [status, address, chainId]);

  return (
    <div className="inline-flex items-center gap-2 rounded-full px-3 py-1.5 border bg-card/60">
      <span className={`inline-block w-2 h-2 rounded-full ${status==='connected'?'bg-emerald-500': status==='connecting'?'bg-amber-500':'bg-rose-500'}`}></span>
      <span className="text-xs whitespace-nowrap">{label}</span>
      {status==='connected' && (
        <>
          <button onClick={copy} className="text-xs px-2 py-0.5 rounded hover:bg-muted/60">Copy</button>
          <button onClick={disconnect} className="text-xs px-2 py-0.5 rounded hover:bg-muted/60">Disconnect</button>
        </>
      )}
    </div>
  );
}
