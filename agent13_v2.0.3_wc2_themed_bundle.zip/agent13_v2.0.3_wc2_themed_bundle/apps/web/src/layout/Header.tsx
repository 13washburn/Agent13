import React from 'react';
import HeaderWalletChip from '../components/HeaderWalletChip';

export default function Header(){
  return (
    <header className="w-full flex items-center justify-between px-4 py-2 border-b bg-background/80">
      <div className="flex items-center gap-3">
        <img src="/agent13-logo.svg" onError={(e)=>{(e.currentTarget as HTMLImageElement).style.display='none';}} alt="Agent 13" className="w-6 h-6" />
        <span className="font-semibold">Agent 13</span>
      </div>
      <div className="flex items-center gap-3">
        <HeaderWalletChip />
      </div>
    </header>
  );
}
