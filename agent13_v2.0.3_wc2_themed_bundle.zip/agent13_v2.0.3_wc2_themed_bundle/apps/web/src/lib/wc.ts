import EthereumProvider from '@walletconnect/ethereum-provider';
import { loadSession } from './walletSession';

export type Theming = {
  appName?: string;
  appDescription?: string;
  accentColor?: string; // hex
  backgroundColor?: string; // hex
  appIcon?: string; // url or data URI
};

export function readProjectId(): string | undefined {
  const anyGlobal: any = (globalThis as any);
  return (anyGlobal?.import?.meta?.env?.VITE_WC_PROJECT_ID)
      || (anyGlobal?.process?.env?.NEXT_PUBLIC_WC_PROJECT_ID)
      || (anyGlobal?.__WC_PROJECT_ID);
}

/**
 * Create a WalletConnect provider with optional theming.
 * Uses the QR modal from the provider; color hints are passed via CSS vars.
 */
export async function getWCProvider(projectId: string, chains: number[] = [1], theme?: Theming){
  // Basic CSS var injection for theming (works with WC modal defaults)
  if (theme) {
    const root = document.documentElement.style;
    if (theme.accentColor) root.setProperty('--w3m-accent', theme.accentColor);
    if (theme.backgroundColor) root.setProperty('--w3m-background', theme.backgroundColor);
  }

  const provider = await EthereumProvider.init({ projectId, showQrModal: true, chains });
  // Request accounts will open QR if not yet connected
  await provider.request({ method: 'eth_requestAccounts' });
  return provider as any; // EIP-1193
}

/**
 * Attempt silent reconnect for WC if we have a cached session.
 * Returns a provider or null.
 */
export async function tryReconnectWC(projectId: string){
  const cached = loadSession();
  if (!cached || cached.type !== 'wc') return null;
  try {
    const provider = await EthereumProvider.init({ projectId, showQrModal: false, optionalChains: [cached.chainId] });
    // Try a read without prompting
    const accounts = await provider.request({ method: 'eth_accounts' });
    if (Array.isArray(accounts) && accounts.length > 0) return provider as any;
    return null;
  } catch { return null; }
}

export function shorten(addr?: string){ return addr ? `${addr.slice(0,6)}…${addr.slice(-4)}` : ''; }
