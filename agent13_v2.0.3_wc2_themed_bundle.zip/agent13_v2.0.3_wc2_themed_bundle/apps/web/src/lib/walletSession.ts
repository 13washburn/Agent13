export type WalletSession = {
  type: 'wc' | 'injected';
  address: string;
  chainId: number;
  timestamp: number;
};

const KEY = 'agent13_wallet_session';

export function saveSession(s: WalletSession){
  try { localStorage.setItem(KEY, JSON.stringify(s)); } catch {}
}

export function loadSession(): WalletSession | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch { return null; }
}

export function clearSession(){ try { localStorage.removeItem(KEY); } catch {} }
