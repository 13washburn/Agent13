## 2.0.3 — WC2 Themed + Wallet Status + Reconnect (2026-03-01)
- Themed Web3Modal (Agent 13 brand)
- Wallet status chip in header (address + network)
- Reconnect persistence and session restore
