#!/usr/bin/env bash
set -euo pipefail
VERSION=1.9.0
API_IMG=agent13-api:$VERSION
WEB_IMG=agent13-web:$VERSION
pnpm install
pnpm run build && pnpm run test

docker build -t "$API_IMG" ./apps/api

docker build -t "$WEB_IMG" ./apps/web

mkdir -p dist/release
./scripts/print_digests.sh > dist/release/agent13_v$VERSION\_digests.txt || true
printf "
Release images built: %s, %s
" "$API_IMG" "$WEB_IMG"
