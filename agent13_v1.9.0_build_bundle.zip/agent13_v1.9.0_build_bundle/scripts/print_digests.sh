#!/usr/bin/env bash
set -euo pipefail
VERSION=1.9.0
API_IMG=agent13-api:$VERSION
WEB_IMG=agent13-web:$VERSION

echo "# Image digests (Agent 13 v$VERSION)"
echo
if docker image inspect "$API_IMG" >/dev/null 2>&1; then
  docker image inspect --format='API {{.RepoDigests}}' "$API_IMG"
else
  echo "API image not found: $API_IMG" >&2
fi
if docker image inspect "$WEB_IMG" >/dev/null 2>&1; then
  docker image inspect --format='WEB {{.RepoDigests}}' "$WEB_IMG"
else
  echo "WEB image not found: $WEB_IMG" >&2
fi
