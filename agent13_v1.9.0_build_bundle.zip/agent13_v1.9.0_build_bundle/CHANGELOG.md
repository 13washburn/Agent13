## 1.9.0 — Screener Prime+ (2026-03-01)
- Single global header + single Toolbox across split view (Stage 2 + Stage 4)
- Clickable asset → Live Chart drawer/panel with arrows (↑ Stage 2, ↓ Stage 4)
- Added 3‑panel mode (Stage 2 + Stage 4 + Chart)
- Added LIVE dot in header (green=live, red=stalled) with explicit SSE heartbeats
- Provider Health pill retained with expanded popover
- Sounds: Stage 2 breakout, Stage 4 breakdown (enabled), Squeeze (both stages)
- Full build artifacts and scripts updated to v1.9.0
