import { useEffect, useRef, useState } from 'react';

type Status = 'live' | 'stalled';
const STALE_MS = 30_000; // 30s without messages → stalled

export default function LiveDot({ source }: { source: EventSource | null }) {
  const [status, setStatus] = useState<Status>('stalled');
  const lastMsg = useRef<number>(0);
  const timer = useRef<any>(null);

  useEffect(() => {
    function tick() {
      const age = Date.now() - (lastMsg.current || 0);
      setStatus(age < STALE_MS ? 'live' : 'stalled');
    }
    timer.current = setInterval(tick, 5000);
    return () => clearInterval(timer.current);
  }, []);

  useEffect(() => {
    if (!source) { setStatus('stalled'); return; }
    const onOpen = () => { lastMsg.current = Date.now(); setStatus('live'); };
    const onError = () => setStatus('stalled');
    const onAny = () => { lastMsg.current = Date.now(); };

    source.addEventListener('open', onOpen as any);
    source.addEventListener('error', onError as any);
    source.addEventListener('message', onAny as any);
    source.addEventListener('squeeze', onAny as any);
    source.addEventListener('hb', onAny as any);

    return () => {
      source.removeEventListener('open', onOpen as any);
      source.removeEventListener('error', onError as any);
      source.removeEventListener('message', onAny as any);
      source.removeEventListener('squeeze', onAny as any);
      source.removeEventListener('hb', onAny as any);
    };
  }, [source]);

  const isLive = status === 'live';
  const color = isLive ? 'bg-emerald-500' : 'bg-rose-500';
  const label = isLive ? 'Live' : 'Reconnecting…';

  return (
    <div className="flex items-center gap-2" aria-live="polite" aria-atomic="true">
      <span className={`inline-block w-2.5 h-2.5 rounded-full ${color} shadow-sm`} title={label} aria-label={label} role="status" />
      <span className="hidden sm:inline text-xs text-muted-foreground">{label}</span>
    </div>
  );
}
