import React from 'react';

type Props = {
  open: boolean;
  onClose: () => void;
  symbol: string | null;
  stage: 2 | 4 | null;
  name?: string | null;
};

// Minimal placeholder: wire to your charting lib here
export default function ChartPanel({ open, onClose, symbol, stage, name }: Props){
  if (!open || !symbol || !stage) return null;
  const arrow = stage === 2 ? '↑' : '↓';
  const arrowColor = stage === 2 ? 'text-emerald-500' : 'text-rose-500';
  return (
    <aside className="fixed right-0 top-0 h-full w-full md:w-[560px] bg-background/95 backdrop-blur border-l shadow-xl z-50">
      <div className="p-4 flex items-center justify-between border-b">
        <div className="flex items-center gap-2 text-base font-semibold">
          <span className={arrowColor}>{arrow}</span>
          <span>{symbol}</span>
          {name ? <span className="text-muted-foreground text-sm">{name}</span> : null}
        </div>
        <button onClick={onClose} className="rounded-xl px-3 py-1 bg-muted hover:bg-muted/70 text-sm">Close</button>
      </div>
      <div className="p-4 h-[calc(100%-56px)]">
        {/* Replace with real chart component; the container is ready */}
        <div className="h-full rounded-2xl border bg-card/40 grid place-items-center text-muted-foreground">
          Live chart for {symbol} ({stage === 2 ? 'Stage 2 Uptrend' : 'Stage 4 Downtrend'})
        </div>
      </div>
    </aside>
  );
}
