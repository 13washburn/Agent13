import { useEffect, useRef, useState } from 'react';
import LiveDot from '@/components/LiveDot';
import ProviderHealthPill from '@/components/ProviderHealthPill';
import ChartPanel from './ChartPanel';

type Signal = {
  symbol: string;
  name?: string;
  assetClass: 'stock' | 'crypto';
  stage: 2 | 4;
  signalType: 'breakout' | 'breakdown';
  score: number;
  timestamp: string;
  price: number;
};

export default function ScreenerView() {
  const [tab, setTab] = useState<2 | 4>(2);
  const [signals, setSignals] = useState<Signal[]>([]);
  const [topCount, setTopCount] = useState<3 | 10>(3);
  const [threePanel, setThreePanel] = useState(false);
  const [chartOpen, setChartOpen] = useState(false);
  const [chartSymbol, setChartSymbol] = useState<string | null>(null);
  const [chartStage, setChartStage] = useState<2 | 4 | null>(null);
  const [chartName, setChartName] = useState<string | null>(null);
  const esRef = useRef<EventSource | null>(null);
  const squeezeRef = useRef<Record<string, number>>({});

  useEffect(() => {
    esRef.current?.close();
    const es = new EventSource(`/api/stream/signals?stage=${tab}`);
    esRef.current = es;

    es.onmessage = (e) => {
      const sig: Signal = JSON.parse(e.data);
      setSignals(prev => mergeAndRank([sig, ...prev]));
      if (sig.stage === 2 && sig.signalType === 'breakout') playBreakout();
      if (sig.stage === 4 && sig.signalType === 'breakdown') playBreakdown();
    };
    es.addEventListener('squeeze', (e: MessageEvent) => {
      const ev = JSON.parse(e.data);
      if (shouldChimeSqueeze(ev.symbol)) playSqueeze();
    });
    es.onerror = () => { /* LiveDot will flip to stalled automatically */ };
    return () => es.close();
  }, [tab]);

  const top = signals.slice(0, topCount);

  function openChart(s: Signal){
    setChartSymbol(s.symbol); setChartStage(s.stage); setChartName(s.name ?? null); setChartOpen(true);
    if (threePanel === false) setThreePanel(true); // auto-enable 3-panel when opening
  }

  return (
    <div className="h-full flex flex-col">
      <header className="mb-3 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <LiveDot source={esRef.current} />
          <TabButton active={tab===2} onClick={() => setTab(2)} label="Stage 2 Breakouts" />
          <TabButton active={tab===4} onClick={() => setTab(4)} label="Stage 4 Breakdowns" />
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={()=>setThreePanel(v=>!v)}
            className="text-xs rounded-full px-3 py-1.5 bg-muted hover:bg-muted/70"
            aria-pressed={threePanel}
            title="Toggle 3-panel mode"
          >{threePanel ? '3‑Panel On' : '3‑Panel Off'}</button>
          <span className="text-xs text-muted-foreground">Top</span>
          <select className="text-xs rounded-lg bg-muted px-2 py-1" value={topCount} onChange={(e)=>setTopCount(Number(e.target.value) as 3|10)}>
            <option value={3}>3</option>
            <option value={10}>10</option>
          </select>
          <ProviderHealthPill />
        </div>
      </header>

      <div className={`grid gap-4 ${threePanel ? 'grid-cols-1 xl:grid-cols-3' : 'grid-cols-1 xl:grid-cols-2'}`}>
        <section className="border rounded-2xl p-3">
          <h2 className="text-base font-semibold mb-2">Stage 2 Uptrends</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
            {top.filter(s=>s.stage===2).slice(0,3).map((s,i)=> (
              <SignalCard key={i} signal={s} onClick={()=>openChart(s)} arrow="up" />
            ))}
          </div>
          <SignalTable signals={signals.filter(s=>s.stage===2)} onRowClick={openChart} />
        </section>

        <section className="border rounded-2xl p-3">
          <h2 className="text-base font-semibold mb-2">Stage 4 Downtrends</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
            {top.filter(s=>s.stage===4).slice(0,3).map((s,i)=> (
              <SignalCard key={i} signal={s} onClick={()=>openChart(s)} arrow="down" />
            ))}
          </div>
          <SignalTable signals={signals.filter(s=>s.stage===4)} onRowClick={openChart} />
        </section>

        {threePanel && (
          <section className="border rounded-2xl p-3 hidden xl:block">
            <h2 className="text-base font-semibold mb-2">Chart</h2>
            <div className="h-[520px] rounded-xl border bg-card/40 grid place-items-center text-muted-foreground">
              {chartSymbol ? `${chartSymbol} (${chartStage===2?'Stage 2':'Stage 4'})` : 'Open a symbol to view chart'}
            </div>
          </section>
        )}
      </div>

      <ChartPanel open={chartOpen} onClose={()=>setChartOpen(false)} symbol={chartSymbol} stage={chartStage} name={chartName} />
    </div>
  );

  function mergeAndRank(items: Signal[]) {
    const uniq = new Map<string, Signal>();
    for (const it of items) {
      const k = `${it.symbol}-${it.stage}`;
      if (!uniq.has(k) || new Date(it.timestamp) > new Date(uniq.get(k)!.timestamp)) uniq.set(k, it);
    }
    return Array.from(uniq.values()).sort((a,b)=> (b.score - a.score) || (+new Date(b.timestamp) - +new Date(a.timestamp)));
  }

  function shouldChimeSqueeze(sym: string) {
    const now = Date.now(); const last = squeezeRef.current[sym] ?? 0; if (now - last < 30_000) return false; squeezeRef.current[sym] = now; return true;
  }
}

function TabButton({active,onClick,label}:{active:boolean; onClick:()=>void; label:string}){
  return <button onClick={onClick} className={`px-3 py-1.5 rounded-xl text-sm ${active? 'bg-muted' : 'hover:bg-muted/60'}`}>{label}</button>;
}

function SignalCard({signal, onClick, arrow}:{signal: any; onClick:()=>void; arrow:'up'|'down'}){
  return (
    <button onClick={onClick} className="text-left border rounded-2xl p-3 hover:bg-muted/40 transition">
      <div className="flex items-start justify-between">
        <div>
          <div className="text-lg font-semibold">{signal.symbol}</div>
          <div className="text-xs text-muted-foreground">{signal.name}</div>
        </div>
        <div className={`text-lg ${arrow==='up'?'text-emerald-500':'text-rose-500'}`}>{arrow==='up'?'↑':'↓'}</div>
      </div>
      <div className="mt-2 grid grid-cols-2 text-sm">
        <div className="text-muted-foreground">{signal.signalType === 'breakout' ? 'Breakout' : 'Breakdown'}</div>
        <div className="text-right font-semibold">{signal.price}</div>
      </div>
      <div className="text-xs text-muted-foreground mt-1">30W MA + volume</div>
    </button>
  );
}

function SignalTable({signals, onRowClick}:{signals:any[]; onRowClick:(s:any)=>void}){
  return (
    <div className="rounded-2xl border overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-muted/60">
          <tr>
            <th className="text-left px-3 py-2">Symbol</th>
            <th className="text-left px-3 py-2">Name</th>
            <th className="text-left px-3 py-2">Signal</th>
            <th className="text-right px-3 py-2">Price</th>
            <th className="text-right px-3 py-2">Signal Time</th>
          </tr>
        </thead>
        <tbody>
          {signals.map((s,i)=> (
            <tr key={i} className="hover:bg-muted/40 cursor-pointer" onClick={()=>onRowClick(s)}>
              <td className="px-3 py-2 font-medium">{s.symbol}</td>
              <td className="px-3 py-2">{s.name}</td>
              <td className="px-3 py-2">{s.signalType==='breakout'?'Breakout':'Breakdown'}</td>
              <td className="px-3 py-2 text-right">{s.price}</td>
              <td className="px-3 py-2 text-right">{new Date(s.timestamp).toLocaleTimeString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function playBreakout(){
  const ctx = new (window.AudioContext || (window as any).webkitAudioContext)(); const o = ctx.createOscillator(), g = ctx.createGain();
  o.type='triangle'; o.frequency.value=880; g.gain.setValueAtTime(0.0001, ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.06, ctx.currentTime+0.02); g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime+0.20); o.connect(g).connect(ctx.destination); o.start(); o.stop(ctx.currentTime+0.22);
}
function playBreakdown(){
  const ctx = new (window.AudioContext || (window as any).webkitAudioContext)(); const o = ctx.createOscillator(), g = ctx.createGain();
  o.type='sawtooth'; o.frequency.value=392.0; g.gain.setValueAtTime(0.0001, ctx.currentTime); g.gain.linearRampToValueAtTime(0.035, ctx.currentTime+0.02); g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime+0.20); o.connect(g).connect(ctx.destination); o.start(); o.stop(ctx.currentTime+0.22);
}
function playSqueeze(){
  const ctx = new (window.AudioContext || (window as any).webkitAudioContext)(); const o = ctx.createOscillator(), g = ctx.createGain();
  o.type='sine'; o.frequency.value=1319.0; g.gain.setValueAtTime(0.0001, ctx.currentTime); g.gain.linearRampToValueAtTime(0.04, ctx.currentTime+0.015); g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime+0.18); o.connect(g).connect(ctx.destination); o.start(); o.stop(ctx.currentTime+0.20);
}
