export type ProviderKey = 'sip' | 'polygon' | 'kaiko' | 'coinapi' | 'ccxt';
export type HealthSample = { ts: number; latency: number; ok: boolean; err?: string };

type ProviderState = {
  key: ProviderKey;
  lastOkTs: number | null;
  lastErrTs: number | null;
  samples: HealthSample[];
  connected: boolean;
};

const providers: Record<ProviderKey, ProviderState> = {
  sip:      { key: 'sip',      lastOkTs: null, lastErrTs: null, samples: [], connected: false },
  polygon:  { key: 'polygon',  lastOkTs: null, lastErrTs: null, samples: [], connected: false },
  kaiko:    { key: 'kaiko',    lastOkTs: null, lastErrTs: null, samples: [], connected: false },
  coinapi:  { key: 'coinapi',  lastOkTs: null, lastErrTs: null, samples: [], connected: false },
  ccxt:     { key: 'ccxt',     lastOkTs: null, lastErrTs: null, samples: [], connected: false },
};

const WINDOW_MS = 5 * 60 * 1000; // 5 min

export function recordProbe(key: ProviderKey, sample: HealthSample) {
  const p = providers[key];
  p.samples.push(sample);
  p.connected = sample.ok || p.connected;
  if (sample.ok) p.lastOkTs = sample.ts; else p.lastErrTs = sample.ts;
  const cutoff = Date.now() - WINDOW_MS;
  p.samples = p.samples.filter(s => s.ts >= cutoff);
}

export function setConnected(key: ProviderKey, connected: boolean) {
  providers[key].connected = connected;
}

function pct(n: number, d: number) { return d === 0 ? 0 : (n / d) * 100; }
function p50(latencies: number[]) {
  if (!latencies.length) return null as number | null;
  const a = [...latencies].sort((x,y)=>x-y);
  return a[Math.floor(a.length * 0.5)];
}

function statusFor(p: ProviderState) {
  const now = Date.now();
  const lastOkAge = p.lastOkTs ? (now - p.lastOkTs) : Infinity;
  const okCount  = p.samples.filter(s => s.ok).length;
  const errCount = p.samples.filter(s => !s.ok).length;
  const errRate  = pct(errCount, okCount + errCount);
  const lats     = p.samples.filter(s => s.ok).map(s => s.latency);
  const p50lat   = p50(lats);

  const ageGreen  = 10_000;
  const ageAmber  = 60_000;
  const errAmber  = 10;
  const errGreen  = 2;

  let status: 'green' | 'amber' | 'red' = 'green';
  if (lastOkAge > ageAmber || !p.connected) status = 'red';
  else if (lastOkAge > ageGreen || errRate >= errGreen) status = 'amber';
  if (errRate >= errAmber) status = 'red';

  return {
    key: p.key, status, connected: p.connected,
    lastOkAgeMs: isFinite(lastOkAge) ? lastOkAge : null,
    p50LatencyMs: p50lat,
    errRatePct: Math.round(errRate * 10) / 10,
    sampleCount: p.samples.length,
    lastErrTs: p.lastErrTs,
  };
}

export function snapshot() { return Object.values(providers).map(statusFor); }
