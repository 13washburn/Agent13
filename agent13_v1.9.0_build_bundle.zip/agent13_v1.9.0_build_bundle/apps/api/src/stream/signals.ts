import express from 'express';
import { bus } from '../bus'; // your internal event bus

export const router = express.Router();

router.get('/api/stream/signals', (req, res) => {
  const stage = Number(req.query.stage) as 2 | 4 | undefined;

  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
  });

  // initial comment (helps clients flag live)
  res.write(`: connected ${Date.now()}

`);

  const sub = bus.subscribe((evt: any) => {
    if (evt.type === 'signal') {
      if (!stage || evt.stage === stage) res.write(`data: ${JSON.stringify(evt)}

`);
    }
    if (evt.type === 'squeeze_fired') {
      res.write(`event: squeeze
` + `data: ${JSON.stringify(evt)}

`);
    }
  });

  const hb = setInterval(() => {
    res.write(`: hb ${Date.now()}

`); // SSE comment heartbeat
  }, 15000);

  req.on('close', () => { sub.unsubscribe(); clearInterval(hb); });
});
