import express from 'express';
import { snapshot } from '../health/providerHealth';

export const router = express.Router();

router.get('/api/health/providers', (req, res) => {
  res.json({ ts: Date.now(), items: snapshot() });
});

router.get('/api/stream/health', (req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });
  const hb = setInterval(() => {
    res.write(`data: ${JSON.stringify({ ts: Date.now(), items: snapshot() })}

`);
  }, 5000);
  req.on('close', () => clearInterval(hb));
});
