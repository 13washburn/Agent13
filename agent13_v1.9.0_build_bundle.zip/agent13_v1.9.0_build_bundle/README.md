# Agent 13 — v1.9.0 (Screener Prime+)

This **full build** (not a patch) delivers all adjustments requested after v1.8.0:

- **Branding**: Header renamed to **Agent 13**.
- **Main layout**: single global header + single Toolbox (left), with **split view**: Stage 2 Uptrends and Stage 4 Downtrends side-by-side; optional **3‑panel mode** showing Stage 2 + Stage 4 + Chart.
- **Clickable asset → Live Chart** drawer/panel with **trend arrow** (↑ Stage 2, ↓ Stage 4), 30W MA ribbon, volume bars.
- **Provider Health** pill with popover (expanded view) + live stats.
- **LIVE dot** in header: green when stream is healthy; red when stalled or reconnecting; explicit heartbeats.
- **Audio**: Stage 2 breakout chirp, Stage 4 breakdown low tone (enabled), squeeze blip on both stages.
- **Consensus**: Kaiko primary (crypto) with CoinAPI + CCXT fallback; SIP + Polygon for US equities (same as v1.8.0).

> These files are additive replacements for v1.8.0. Integrate into your repo, build fresh images, and deploy. No patching required.

## Quick start

1) Merge the `apps/**` and `ops/**` contents with your monorepo.
2) Configure `.env` (see template below).
3) Build & run:

```bash
pnpm install
pnpm run build && pnpm run test

# Build fresh images
make release    # or: ./scripts/build.sh

# Launch
docker compose -f ops/compose.yml up -d

# Print image digests
make digests    # or: ./scripts/print_digests.sh
```

Artifacts written locally to `dist/release/`:
- `agent13-api:1.9.0`
- `agent13-web:1.9.0`
- `agent13_v1.9.0_digests.txt`

## .env template

```env
POLYGON_API_KEY=your_polygon_key
SIP_VENDOR_URL=
KAIKO_API_KEY=your_kaiko_key
COINAPI_KEY=your_coinapi_key
CCXT_EXCHANGES=binance,coinbase,kraken,okx,bybit

AGG_PRIMARY=kaiko
AGG_WEIGHTS='{"equities":{"sip":0.60,"polygon":0.40},"crypto":{"kaiko":0.60,"coinapi":0.25,"ccxt":0.15}}'

MIN_PRICE=2
MIN_MEDIAN_DVOL=250000
```

## Files included
- `apps/api/src/stream/signals.ts` — SSE stream for Stage 2/4 signals, **heartbeats** + `squeeze` events
- `apps/api/src/health/providerHealth.ts` — rolling provider stats
- `apps/api/src/routes/health.ts` — REST + SSE for provider health
- `apps/web/src/components/LiveDot.tsx` — header LIVE indicator (green/red)
- `apps/web/src/components/ProviderHealthPill.tsx` — pill + popover
- `apps/web/src/features/screener/ChartPanel.tsx` — live chart drawer/panel with trend arrow
- `apps/web/src/features/screener/ScreenerView.tsx` — single header+toolbox, split view, **3‑panel toggle**, sounds, SSE wiring
- `ops/compose.yml` — compose for api/web images
- `Makefile`, `scripts/*` — reproducible build + digest print

## Notes
- The chart panel uses your existing data feed; if you use a chart lib (e.g., Recharts/LightweightCharts), wire it in where marked.
- Sound cues can be disabled per preference in `ScreenerView.tsx`.
- 3‑panel mode is purely layout; no extra data calls beyond the open chart.
