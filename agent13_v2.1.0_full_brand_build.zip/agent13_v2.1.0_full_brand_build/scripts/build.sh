#!/usr/bin/env bash
set -euo pipefail
make release
