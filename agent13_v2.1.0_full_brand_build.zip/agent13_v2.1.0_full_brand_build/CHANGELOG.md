## 2.1.0 — Full Brand Integration (2026-03-01)
- Replaced all visible "Agent 13" instances with "Agent [LOGO]"
- Added brand CSS, font, and reusable `<BrandWordmark />` component
- Included SVG logo + favicon
- Compose & Makefile bumped to 2.1.0
