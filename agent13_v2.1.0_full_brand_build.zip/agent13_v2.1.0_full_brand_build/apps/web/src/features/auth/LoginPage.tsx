import React from 'react';
import BrandWordmark from '../../components/BrandWordmark';

export default function LoginPage(){
  return (
    <div className="min-h-screen grid place-items-center p-6">
      <div className="w-[420px] max-w-full">
        <div className="flex items-center justify-center mb-6">
          <BrandWordmark size="xl" />
        </div>
        <div className="border rounded-2xl p-6 bg-card/50 grid gap-2">
          <a className="px-3 py-2 rounded-xl border hover:bg-muted/60" href="/api/auth/google/start">Continue with Google</a>
          <a className="px-3 py-2 rounded-xl border hover:bg-muted/60" href="/api/auth/apple/start">Continue with Apple</a>
          <a className="px-3 py-2 rounded-xl border hover:bg-muted/60" href="/connect-wallet">Connect Wallet</a>
          <a className="px-3 py-2 rounded-xl border hover:bg-muted/60" href="/broker">Continue with Brokerage</a>
          <div className="h-px bg-border my-2" />
          <a className="px-3 py-2 rounded-xl border hover:bg-muted/60" href="/magic-link">Continue with Email</a>
          <a className="px-3 py-2 rounded-xl border hover:bg-muted/60" href="/passkey">Use a Passkey</a>
          <p className="text-xs text-muted-foreground mt-2 text-center">We never post or trade without your explicit consent. You control broker scopes.</p>
        </div>
      </div>
    </div>
  );
}
