import React from 'react';
import '../styles/brand.css';

export default function BrandWordmark({size='md'}:{size?:'sm'|'md'|'lg'|'xl'}){
  const cls = size==='xl' ? 'brand-logo xl' : size==='lg' ? 'brand-logo lg' : 'brand-logo';
  const textCls = size==='xl' ? 'text-3xl' : size==='lg' ? 'text-2xl' : 'text-lg';
  return (
    <span className={`brand-wordmark ${textCls}`}>Agent <img src="/brand/agent13_logo_metallic.svg" alt="13" className={cls}/></span>
  );
}
