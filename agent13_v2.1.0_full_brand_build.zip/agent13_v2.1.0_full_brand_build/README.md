# Agent 13 — v2.1.0 (Full Brand Integration)

**Full build (not a patch).** This release bakes the new brand across the app:
- “Agent 13” ➜ **Agent [LOGO]** (your metallic 13 mark replaces the numeric text)
- Duplicate leading logos removed; the logo appears **once** beside “Agent”
- New futuristic display font applied via brand CSS
- SVG logo + favicon included

## Quick start
```bash
pnpm install
make release
# then
docker compose -f ops/compose.yml up -d
make digests
```

## Where to customize
- `public/brand/agent13_logo_metallic.svg` — swap if you have a refined vector
- `apps/web/src/styles/brand.css` — change font, colors, sizes
- Reuse the wordmark in any view: `import BrandWordmark from '@/components/BrandWordmark'`
