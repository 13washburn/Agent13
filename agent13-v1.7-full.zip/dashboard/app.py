import os, requests, pandas as pd, altair as alt
import streamlit as st

API_BASE = os.getenv('API_BASE','http://localhost:8000')

st.set_page_config(page_title='Agent 13', layout='wide')
with open('assets/tokens.css') as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

# Header with WS health and theme toggle
col1, col2 = st.columns([0.5,0.5])
with col1:
    st.markdown('## Agent 13')
with col2:
    try:
        ws = requests.get(f"{API_BASE}/ws/health", timeout=2).json().get('status',{})
    except Exception:
        ws = {}
    agg = 'ok' if any(v=='ok' for v in ws.values()) else ('partial' if any(v=='partial' for v in ws.values()) else ('stall' if any(v=='stall' for v in ws.values()) else 'idle'))
    cls={'ok':'ws-ok','partial':'ws-partial','stall':'ws-stall','idle':'ws-idle'}[agg]
    st.markdown(f"<div style='text-align:right'><span class='badge'><span class='ws-dot {cls}'></span>LIVE</span></div>", unsafe_allow_html=True)
    light = st.toggle('Light mode', value=False, key='light_mode')
    if light:
        st.markdown('<style>:root{--bg:#ffffff;--bg-elev:#f5f7fa;--text:#0d1218;--muted:#5b6571;--border:#dfe5ec;--accent:#0ea5e9;--pos:#0aa980;--neg:#ff8a2b;--info:#2b74ff}</style>', unsafe_allow_html=True)

st.markdown('---')

left,right = st.columns([0.28,0.72])

# Left rail — Recent Signals + Bankr Activity + policy
with left:
    st.subheader('Recent Signals')
    sym = st.text_input('Symbol for feed', value='BTC/USDT', label_visibility='collapsed')
    try:
        feed = requests.get(f"{API_BASE}/signals/recent", params={'symbol': sym, 'limit': 12}, timeout=6).json()
    except Exception:
        feed = []
    if not feed:
        st.markdown("<div class='card skeleton' style='height:240px'></div>", unsafe_allow_html=True)
    else:
        for s in feed:
            stage = s.get('stage','')
            icon = '▴' if '2' in stage else ('▾' if '4' in stage else '•')
            conf = s.get('confidence') or 0
            dot = "🔵" if conf>=2.5 else ("🟢" if conf>=1.2 else "⚪")
            st.markdown(f"<div class='card' style='margin-bottom:8px'>{icon} <b>{s['symbol']}</b> · {stage} <span style='float:right'>{dot}</span><br><span style='color:var(--muted);font-size:12px'>{s['ts']}</span></div>", unsafe_allow_html=True)

    st.markdown("<div style='margin-top:12px'></div>", unsafe_allow_html=True)
    st.markdown("**Bankr Activity** <span style='color:var(--muted)'>· last 5</span>", unsafe_allow_html=True)
    try:
        jobs = requests.get(f"{API_BASE}/ops/bankr/jobs", params={'symbol': sym, 'limit': 5}, timeout=6).json()
    except Exception:
        jobs = []
    if jobs:
        for j in jobs:
            status = (j.get('status') or '').lower()
            dot = '🟢' if status in ('done','success','completed') else ('🟡' if status in ('in_progress','running') else '🔴')
            jid = (j.get('job_id') or '')[:10] + '…'
            prompt = (j.get('prompt') or '')[:48] + ('…' if len(j.get('prompt',''))>48 else '')
            st.markdown(f"<div class='card' style='margin-bottom:6px'>{dot} <b>{prompt}</b><br><span style='color:var(--muted);font-size:12px'>{jid} · {status}</span></div>", unsafe_allow_html=True)
    else:
        st.markdown("<div class='card' style='opacity:.7'>No recent Bankr jobs for this symbol.</div>", unsafe_allow_html=True)

    with st.expander('Bankr policy'):
        try:
            pol = requests.get(f"{API_BASE}/ops/bankr/policy", timeout=4).json()
            st.json(pol)
        except Exception:
            st.caption('Bankr: unavailable.')

# Right content — analysis
with right:
    st.subheader('Symbol Check')
    from urllib.parse import urlencode
    colA,colB = st.columns([0.6,0.4])
    with colA:
        symbol = st.text_input('Symbol', value='BTC/USDT')
    with colB:
        try:
            m = requests.get(f"{API_BASE}/momentum", params={'symbol': symbol}, timeout=6).json()
            bucket = (m.get('bucket') or 'low').lower()
            micro = {'strong':'Rising','medium':'Stable','low':'Fading'}
            st.markdown(f"<span class='badge {'low' if bucket=='low' else ('medium' if bucket=='medium' else 'strong')}'>Momentum: {micro.get(bucket,'Fading')}</span>", unsafe_allow_html=True)
        except Exception:
            st.markdown("<span class='badge'>Momentum: Fading</span>", unsafe_allow_html=True)

    params={'symbol': symbol}
    params['theme']='light' if st.session_state.get('light_mode') else 'dark'
    params['nbbo']='spread'
    share_url=f"http://localhost:8501/?{urlencode(params)}"
    with st.expander('Share link'):
        st.text_input('Shareable link', value=share_url, label_visibility='collapsed')

    import numpy as np
    dx = pd.DataFrame({'timestamp': pd.date_range('2024-01-01', periods=120, freq='D'), 'close': 100+np.cumsum(np.random.randn(120))})
    base_price = alt.Chart(dx).mark_line(color='#9ad2ff').encode(x='timestamp:T', y='close:Q')
    try:
        last_row = dx.iloc[-1:]
        stg_resp = requests.get(f"{API_BASE}/signals/recent", params={'symbol': symbol, 'limit': 1}, timeout=6).json()
        stage_txt = (stg_resp[0].get('stage') if isinstance(stg_resp, list) and stg_resp else 'Neutral')
        arrow = '▲' if '2' in stage_txt else ('▼' if '4' in stage_txt else '•')
        color = '#2ec7a1' if '2' in stage_txt else ('#ffb14a' if '4' in stage_txt else '#67a5ff')
        last_df = last_row.assign(label=arrow)
        overlay = alt.Chart(last_df).mark_text(fontSize=22, color=color, dy=-8).encode(x='timestamp:T', y='close:Q', text='label:N')
        st.altair_chart((base_price + overlay).properties(height=280).configure_axis(grid=False).configure_view(strokeOpacity=0), use_container_width=True)
    except Exception:
        st.altair_chart(base_price.properties(height=280).configure_axis(grid=False).configure_view(strokeOpacity=0), use_container_width=True)

    try:
        lu = requests.get(f"{API_BASE}/last_updated", params={'symbol': symbol}, timeout=4).json()
        ts_txt = lu.get('ts') or 'n/a'
        from datetime import datetime
        try:
            lt = datetime.fromisoformat((ts_txt or '').replace('Z','+00:00')).astimezone().strftime('%Y-%m-%d %H:%M:%S') if ts_txt else 'n/a'
            st.caption(f"Last updated: {lt} (local) · UTC: {ts_txt}")
        except Exception:
            st.caption(f"Last updated (UTC): {ts_txt}")
    except Exception:
        st.caption("Last updated: n/a")

    c1,c2 = st.columns(2)
    with c1:
        dx['obv']=np.cumsum(np.random.randn(120))
        st.altair_chart(alt.Chart(dx).mark_line(color='#7ce8c7').encode(x='timestamp:T', y='obv:Q').properties(height=160).configure_axis(grid=False).configure_view(strokeOpacity=0), use_container_width=True)
    with c2:
        dx['ad']=np.cumsum(np.random.randn(120))
        st.altair_chart(alt.Chart(dx).mark_line(color='#c8d0ff').encode(x='timestamp:T', y='ad:Q').properties(height=160).configure_axis(grid=False).configure_view(strokeOpacity=0), use_container_width=True)

    if '/' not in symbol:
        try:
            nb = requests.get(f"{API_BASE}/stocks/nbbo/spark", params={'ticker': symbol, 'lookback_min': 60}, timeout=8).json()
            r = nb.get('rows', [])
            if r:
                q = pd.DataFrame(r)
                q['ts'] = pd.to_datetime(q['ts'])
                metric_label = st.selectbox('NBBO metric', ['Spread (bps)', 'Midprice (USD)'], index=0, key='nbbo_metric')
                y_col = 'spread_bps' if metric_label.startswith('Spread') else 'mid'
                color = '#ffb14a' if y_col=='spread_bps' else '#67a5ff'
                sp = alt.Chart(q).mark_line(color=color).encode(x='ts:T', y=alt.Y(f'{y_col}:Q'))
                st.altair_chart(sp.properties(height=120).configure_axis(grid=False).configure_view(strokeOpacity=0), use_container_width=True)
                st.caption('NBBO ' + ('Spread (bps)' if y_col=='spread_bps' else 'Midprice (USD)') + ', last 60 min')
        except Exception:
            st.caption('NBBO: unavailable.')

# pages dir
os.makedirs('pages', exist_ok=True)
