import os, time, requests

BANKR_BASE = os.getenv('BANKR_BASE', 'https://api.bankr.bot')
BANKR_API_KEY = os.getenv('BANKR_API_KEY', '')

class BankrClient:
    def __init__(self, base: str | None = None, api_key: str | None = None):
        self.base = base or BANKR_BASE
        key = api_key or BANKR_API_KEY
        self.headers = {'Content-Type': 'application/json', 'X-API-Key': key}

    def post_prompt(self, prompt: str) -> dict:
        r = requests.post(f"{self.base}/agent/prompt", headers=self.headers, json={'prompt': prompt}, timeout=20)
        r.raise_for_status(); return r.json()

    def get_job(self, job_id: str) -> dict:
        r = requests.get(f"{self.base}/agent/job/{job_id}", headers=self.headers, timeout=20)
        r.raise_for_status(); return r.json()

    def prompt_and_wait(self, prompt: str, timeout_s: int = 30) -> dict:
        job = self.post_prompt(prompt)
        jid = job.get('id') or job.get('jobId') or job.get('job_id')
        if not jid: return {'ok': False, 'error': 'no_job_id', 'raw': job}
        t0 = time.time()
        while time.time() - t0 < timeout_s:
            res = self.get_job(jid)
            status = (res.get('status') or '').lower()
            if status in ('done','completed','success'): return {'ok': True, 'job_id': jid, 'result': res}
            if status in ('error','failed'): return {'ok': False, 'job_id': jid, 'result': res}
            time.sleep(1.5)
        return {'ok': False, 'job_id': jid, 'error': 'timeout'}
