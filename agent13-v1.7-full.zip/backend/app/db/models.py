from typing import Optional
from sqlalchemy.orm import declarative_base, Mapped, mapped_column
from sqlalchemy import String, Double, JSON, TIMESTAMP, text

Base = declarative_base()

class Bar(Base):
    __tablename__ = 'bars'
    id: Mapped[int] = mapped_column(primary_key=True)
    symbol: Mapped[str] = mapped_column(String)
    venue: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    timeframe: Mapped[str] = mapped_column(String)
    ts: Mapped = mapped_column(TIMESTAMP(timezone=True), server_default=text('now()'))
    open: Mapped[Optional[float]] = mapped_column(Double, nullable=True)
    high: Mapped[Optional[float]] = mapped_column(Double, nullable=True)
    low: Mapped[Optional[float]] = mapped_column(Double, nullable=True)
    close: Mapped[Optional[float]] = mapped_column(Double, nullable=True)
    volume: Mapped[Optional[float]] = mapped_column(Double, nullable=True)

class Signal(Base):
    __tablename__ = 'signals'
    id: Mapped[int] = mapped_column(primary_key=True)
    symbol: Mapped[str] = mapped_column(String)
    ts: Mapped = mapped_column(TIMESTAMP(timezone=True), server_default=text('now()'))
    stage: Mapped[str] = mapped_column(String)
    confidence: Mapped[Optional[float]] = mapped_column(Double, nullable=True)
    rvol10: Mapped[Optional[float]] = mapped_column(Double, nullable=True)
    obv_slope: Mapped[Optional[float]] = mapped_column(Double, nullable=True)
    ad_slope: Mapped[Optional[float]] = mapped_column(Double, nullable=True)
    extras: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
