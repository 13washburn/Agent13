CREATE EXTENSION IF NOT EXISTS timescaledb;

CREATE TABLE IF NOT EXISTS bars (
  id BIGSERIAL PRIMARY KEY,
  symbol TEXT NOT NULL,
  venue TEXT NULL,
  timeframe TEXT NOT NULL,
  ts TIMESTAMPTZ NOT NULL,
  open DOUBLE PRECISION,
  high DOUBLE PRECISION,
  low DOUBLE PRECISION,
  close DOUBLE PRECISION,
  volume DOUBLE PRECISION,
  UNIQUE(symbol, timeframe, ts)
);
SELECT create_hypertable('bars', 'ts', if_not_exists => TRUE);
CREATE INDEX IF NOT EXISTS idx_bars_symbol_tf_ts ON bars(symbol, timeframe, ts DESC);

CREATE TABLE IF NOT EXISTS signals (
  id BIGSERIAL PRIMARY KEY,
  symbol TEXT NOT NULL,
  ts TIMESTAMPTZ NOT NULL,
  stage TEXT NOT NULL,
  confidence DOUBLE PRECISION,
  rvol10 DOUBLE PRECISION,
  obv_slope DOUBLE PRECISION,
  ad_slope DOUBLE PRECISION,
  extras JSONB,
  UNIQUE(symbol, ts, stage)
);
SELECT create_hypertable('signals', 'ts', if_not_exists => TRUE);
CREATE INDEX IF NOT EXISTS idx_signals_symbol_ts ON signals(symbol, ts DESC);

CREATE TABLE IF NOT EXISTS stock_trades (
  id BIGSERIAL PRIMARY KEY,
  sym TEXT NOT NULL,
  ts TIMESTAMPTZ NOT NULL,
  price DOUBLE PRECISION,
  size DOUBLE PRECISION,
  conditions JSONB,
  UNIQUE(sym, ts)
);
SELECT create_hypertable('stock_trades', 'ts', if_not_exists => TRUE);
CREATE INDEX IF NOT EXISTS idx_trades_sym_ts ON stock_trades(sym, ts DESC);

CREATE TABLE IF NOT EXISTS stock_quotes (
  id BIGSERIAL PRIMARY KEY,
  sym TEXT NOT NULL,
  ts TIMESTAMPTZ NOT NULL,
  bid DOUBLE PRECISION,
  bidsz DOUBLE PRECISION,
  ask DOUBLE PRECISION,
  asksz DOUBLE PRECISION,
  UNIQUE(sym, ts)
);
SELECT create_hypertable('stock_quotes', 'ts', if_not_exists => TRUE);
CREATE INDEX IF NOT EXISTS idx_quotes_sym_ts ON stock_quotes(sym, ts DESC);

-- Bankr job log
CREATE TABLE IF NOT EXISTS bankr_jobs (
  id BIGSERIAL PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  symbol TEXT NULL,
  prompt TEXT NOT NULL,
  job_id TEXT NULL,
  status TEXT NULL,
  result JSONB NULL,
  source TEXT NULL,
  mode TEXT NULL
);
CREATE INDEX IF NOT EXISTS idx_bankr_jobs_symbol_created ON bankr_jobs(symbol, created_at DESC);
