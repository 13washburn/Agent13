import os, json, asyncio
import websockets
from datetime import datetime, timezone
from sqlalchemy import text as sa_text
from ..db.database import SessionLocal

API_KEY = os.getenv('POLYGON_API_KEY','')
BASE_WS = os.getenv('POLYGON_WS_BASE','wss://socket.polygon.io/stocks')
TICKERS = [t.strip().upper() for t in os.getenv('EQUITY_TICKERS','AAPL,MSFT').split(',') if t.strip()]

async def run():
    if not API_KEY: return
    subs = ','.join([*(f'T.{t}' for t in TICKERS), *(f'Q.{t}' for t in TICKERS)])
    backoff=1
    while True:
        try:
            async with websockets.connect(BASE_WS, ping_interval=20, ping_timeout=20) as ws:
                await ws.send(json.dumps({"action":"auth","params":API_KEY}))
                await asyncio.sleep(0.3)
                await ws.send(json.dumps({"action":"subscribe","params":subs}))
                backoff=1
                while True:
                    data = json.loads(await ws.recv()); msgs = data if isinstance(data,list) else [data]
                    for m in msgs:
                        ev = m.get('ev'); sym=m.get('sym','')
                        db = SessionLocal()
                        try:
                            if ev=='T':
                                ts = datetime.fromtimestamp(int(m.get('t',0))/1000.0, tz=timezone.utc)
                                db.execute(sa_text("INSERT INTO stock_trades(sym, ts, price, size, conditions) VALUES (:sym,:ts,:p,:s,:c) ON CONFLICT (sym, ts) DO NOTHING"),
                                           dict(sym=sym, ts=ts, p=float(m.get('p',0)), s=float(m.get('s',0)), c=json.dumps(m.get('c'))))
                                db.commit()
                            elif ev=='Q':
                                ts = datetime.fromtimestamp(int(m.get('t',0))/1000.0, tz=timezone.utc)
                                db.execute(sa_text("INSERT INTO stock_quotes(sym, ts, bid, bidsz, ask, asksz) VALUES (:sym,:ts,:bp,:bsz,:ap,:asz) ON CONFLICT (sym, ts) DO NOTHING"),
                                           dict(sym=sym, ts=ts, bp=float(m.get('bp',0)), bsz=float(m.get('bs',0)), ap=float(m.get('ap',0)), asz=float(m.get('as',0))))
                                db.commit()
                        finally:
                            db.close()
        except Exception:
            await asyncio.sleep(backoff); backoff=min(backoff*2,60)

if __name__=='__main__':
    asyncio.run(run())
