# Agent 13 — v1.7 (Full Stack)

This release ships a cleaner operator layout and keeps automation minimal:

- **Bankr Activity moved under Recent Signals** in the left rail (compact cards; last 5 jobs per symbol).
- **Right column** stays analytical: Symbol Check with price + **Stage arrow**, **Momentum pill**, OBV/A‑D minis, and NBBO spark (equities).
- Includes **Bankr REST MVP** from v1.6 (client, policy endpoint, metrics, Grafana panel, optional Stage‑2 trigger).

## Quick start
```bash
cp .env.example .env   # set POLYGON_API_KEY for equities; set BANKR_* if using Bankr

docker compose up --build
```

### Services
- Dashboard → http://localhost:8501
- API → http://localhost:8000/docs
- Prometheus → http://localhost:9090
- Alertmanager → http://localhost:9093
- Grafana → http://localhost:3000 (admin/admin)

## Env (Bankr)
```env
BANKR_ENABLED=false
BANKR_DRYRUN=true
BANKR_API_KEY=
BANKR_DEFAULT_BUY_USD=25
BANKR_MIN_CONF=2.0
BANKR_WHITELIST=BTC,ETH
```

## Notes
- Polygon equities WS uses the documented auth → subscribe to `AM.*`, `T.*`, `Q.*`; quotes & trades populate NBBO spark + mini tape.
- Grafana dashboards/data sources are file‑provisioned and auto‑load at startup.
