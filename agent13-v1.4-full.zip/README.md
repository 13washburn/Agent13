# Agent 13 — v1.1 (Full Stack)

This release merges Week 1–3 UX with live momentum (+ endpoints), signals feed, last-updated timestamp, WS health, and the full backend (TimescaleDB, Binance WS, Polygon/Massive WS AM/T/Q, signals worker) plus Prometheus/Alertmanager/Grafana.

## Quick start
```bash
cp .env.example .env   # set POLYGON_API_KEY, optional AIXBT_API_KEY, choose symbols
docker compose up --build
```
- Dashboard → http://localhost:8501
- API → http://localhost:8000/docs  (also: /runbook, /momentum, /signals/recent, /signals/feed, /last_updated, /ws/health)
- Prometheus → http://localhost:9090
- Alertmanager → http://localhost:9093
- Grafana → http://localhost:3000  (admin/admin)


## v1.2 additions
- AIXBT Momentum drawer with 7‑day sparkline (`/momentum/trend`).
- NBBO mini spark (spread bps) for equities via `/stocks/nbbo/spark`.
- Alertmanager receivers enabled by default (email/telegram/teams).
- Local time + UTC caption under price chart.


## v1.3 tweaks
- Momentum microcopy: **Rising / Stable / Fading**.
- NBBO metric switcher: Spread (bps) ↔ Midprice (USD).
- Tour shown as popover with dismiss + Show Tour in sidebar.


## v1.4 polish
- Stage tag badge above price chart (latest signal).
- Mini tape (last 20 trades) under NBBO spark for equities.
- ALERT_DEFAULT_RECEIVER env lets you switch default alert route.
- Header theme toggle (Light mode).
