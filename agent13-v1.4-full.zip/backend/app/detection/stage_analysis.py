import pandas as pd
import numpy as np

def _sma(s: pd.Series, n: int) -> pd.Series:
    return s.rolling(n, min_periods=max(5, n//3)).mean()

def label_stages(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    close = out["close"]; vol = out["volume"].fillna(0)
    out["sma30"] = _sma(close, 30)
    out["sma30_slope"] = out["sma30"].diff(3)
    out["rvol10"] = vol / _sma(vol, 10)
    out["base_high"] = close.rolling(20).max().shift(1)
    out["base_low"]  = close.rolling(20).min().shift(1)
    cond2 = (out["close"] > out["base_high"]*1.01) & (out["sma30_slope"]>0) & (out["rvol10"]>=1.5)
    cond4 = (out["close"] < out["base_low"] *0.99) & (out["sma30_slope"]<0) & (out["rvol10"]>=1.3)
    out["stage"] = np.where(cond2, "Stage 2", np.where(cond4, "Stage 4", "Neutral"))
    return out
