import pandas as pd
import numpy as np

def add_obv_ad(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy().dropna(subset=["close","volume"])  
    close = out["close"]; vol = out["volume"].fillna(0)
    direction = np.sign(close.diff()).fillna(0)
    out["obv"] = (direction * vol).cumsum()
    high = out["high"]; low = out["low"]
    rng = (high - low).replace(0, np.nan)
    clv = ((close - low) - (high - close)) / rng
    clv = clv.fillna(0)
    out["ad"] = (clv * vol).cumsum()
    out["obv_slope"] = out["obv"].diff(6)
    out["ad_slope"]  = out["ad"].diff(6)
    return out
