import asyncio, json, os
from datetime import datetime, timezone
import websockets
from sqlalchemy.dialects.postgresql import insert
from ..db.database import SessionLocal
from ..db.models import Bar

BINANCE_WS = "wss://stream.binance.com:9443/stream"
SYMS = os.getenv('CRYPTO_SYMBOLS','BTC/USDT,ETH/USDT').split(',')
STREAMS = '/'.join([s.replace('/','').lower()+"@kline_1m" for s in SYMS])

async def run():
    url = f"{BINANCE_WS}?streams={STREAMS}"
    backoff=1
    while True:
        try:
            async with websockets.connect(url, ping_interval=20, ping_timeout=20) as ws:
                backoff=1
                while True:
                    msg = json.loads(await ws.recv())
                    d = msg.get('data',{}); k=d.get('k',{})
                    if d.get('e')!='kline' or not k.get('x'): continue
                    symbol = d.get('s','').replace('USDT','/USDT')
                    ts = datetime.fromtimestamp(k['T']/1000, tz=timezone.utc)
                    o,h,l,c,v = map(float,[k['o'],k['h'],k['l'],k['c'],k['v']])
                    db = SessionLocal();
                    try:
                        stmt = insert(Bar).values(symbol=symbol, venue='binance', timeframe='1m', ts=ts,
                                                  open=o, high=h, low=l, close=c, volume=v)
                        stmt = stmt.on_conflict_do_nothing(index_elements=['symbol','timeframe','ts'])
                        db.execute(stmt); db.commit()
                    finally:
                        db.close()
        except Exception:
            await asyncio.sleep(backoff); backoff=min(backoff*2,60)

if __name__=='__main__':
    asyncio.run(run())
