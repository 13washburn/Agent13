import os, json, asyncio
import websockets
from datetime import datetime, timezone
from sqlalchemy.dialects.postgresql import insert
from ..db.database import SessionLocal
from ..db.models import Bar

API_KEY = os.getenv('POLYGON_API_KEY','')
BASE_WS = os.getenv('POLYGON_WS_BASE','wss://socket.polygon.io/stocks')
TICKERS = [t.strip().upper() for t in os.getenv('EQUITY_TICKERS','AAPL,MSFT').split(',') if t.strip()]

async def run():
    if not API_KEY: return
    subs = ','.join([f'AM.{t}' for t in TICKERS])
    backoff=1
    while True:
        try:
            async with websockets.connect(BASE_WS, ping_interval=20, ping_timeout=20) as ws:
                await ws.send(json.dumps({"action":"auth","params":API_KEY}))
                await asyncio.sleep(0.3)
                await ws.send(json.dumps({"action":"subscribe","params":subs}))
                backoff=1
                while True:
                    data = json.loads(await ws.recv())
                    msgs = data if isinstance(data,list) else [data]
                    for m in msgs:
                        if m.get('ev')!='AM': continue
                        o,h,l,c,v = map(float,[m.get('o',0),m.get('h',0),m.get('l',0),m.get('c',0),m.get('v',0)])
                        ts = datetime.fromtimestamp(int(m.get('e',0))/1000.0, tz=timezone.utc)
                        db = SessionLocal();
                        try:
                            stmt = insert(Bar).values(symbol=m.get('sym'), venue='polygon_ws', timeframe='1m', ts=ts,
                                                      open=o, high=h, low=l, close=c, volume=v)
                            stmt = stmt.on_conflict_do_nothing(index_elements=['symbol','timeframe','ts'])
                            db.execute(stmt); db.commit()
                        finally:
                            db.close()
        except Exception:
            await asyncio.sleep(backoff); backoff=min(backoff*2,60)

if __name__=='__main__':
    asyncio.run(run())
