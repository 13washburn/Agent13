import time, pandas as pd
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert
from ..db.database import SessionLocal
from ..db.models import Bar, Signal
from ..detection.indicators import add_obv_ad
from ..detection.stage_analysis import label_stages
from ..momentum.momentum_service import MomentumService

MOM = MomentumService()

def fetch_symbols(db):
    return db.execute(select(Bar.symbol).distinct()).scalars().all()

while True:
    db = SessionLocal()
    try:
        for sym in fetch_symbols(db):
            rows = db.execute(select(Bar).where(Bar.symbol==sym).order_by(Bar.ts.asc())).scalars().all()
            if not rows: continue
            df = pd.DataFrame([{ 'timestamp': r.ts, 'open': r.open, 'high': r.high, 'low': r.low, 'close': r.close, 'volume': r.volume } for r in rows]).set_index('timestamp')
            df = add_obv_ad(df); lab = label_stages(df)
            lab['confidence'] = lab['rvol10'].clip(lower=0, upper=3).fillna(0)
            pj = MOM.map_symbol(sym)
            if pj and pj.get('id'):
                sc = MOM.momentum_score(pj['id'])
                if sc is not None:
                    lab['confidence'] = (lab['confidence'] + min(sc/100.0, 0.5)).clip(0, 3.5)
            lab = lab.tail(5)
            for ts, row in lab.iterrows():
                stmt = insert(Signal).values(symbol=sym, ts=ts, stage=row['stage'], confidence=float(row.get('confidence',0) or 0), rvol10=float(row.get('rvol10',0) or 0), obv_slope=float(row.get('obv_slope',0) or 0), ad_slope=float(row.get('ad_slope',0) or 0), extras=None).on_conflict_do_nothing(index_elements=['symbol','ts','stage'])
                db.execute(stmt)
        db.commit()
    except Exception:
        db.rollback()
    finally:
        db.close()
    time.sleep(30)
