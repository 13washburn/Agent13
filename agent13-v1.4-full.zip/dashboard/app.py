import os, requests, pandas as pd, altair as alt
import streamlit as st

API_BASE = os.getenv('API_BASE','http://localhost:8000')

st.set_page_config(page_title='Agent 13', layout='wide')
with open('assets/tokens.css') as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

# Header with WS health
col1, col2 = st.columns([0.5,0.5])
with col1:
    st.markdown('## Agent 13')
with col2:
    try:
        ws = requests.get(f"{API_BASE}/ws/health", timeout=2).json().get('status',{})
    except Exception:
        ws = {}
    agg = 'ok' if any(v=='ok' for v in ws.values()) else ('partial' if any(v=='partial' for v in ws.values()) else ('stall' if any(v=='stall' for v in ws.values()) else 'idle'))
    cls={'ok':'ws-ok','partial':'ws-partial','stall':'ws-stall','idle':'ws-idle'}[agg]
    
st.markdown(f"<div style='text-align:right'><span class='badge'><span class='ws-dot {cls}'></span>LIVE</span></div>", unsafe_allow_html=True)
light = st.toggle('Light mode', value=False, key='light_mode')
if light:
    st.markdown('<style>:root{--bg:#ffffff;--bg-elev:#f5f7fa;--text:#0d1218;--muted:#5b6571;--border:#dfe5ec;--accent:#0ea5e9;--pos:#0aa980;--neg:#ff8a2b;--info:#2b74ff}</style>', unsafe_allow_html=True)


st.markdown('---')
st.markdown("")

left,right = st.columns([0.28,0.72])

# Left rail — feed
with left:
    st.subheader('Recent Signals')
    sym = st.text_input('Symbol for feed', value='BTC/USDT', label_visibility='collapsed')
    try:
        feed = requests.get(f"{API_BASE}/signals/recent", params={'symbol': sym, 'limit': 12}, timeout=6).json()
    except Exception:
        feed = []
    if not feed:
        st.markdown("<div class='card skeleton' style='height:240px'></div>", unsafe_allow_html=True)
    else:
        for s in feed:
            stage = s.get('stage','')
            icon = '▴' if '2' in stage else ('▾' if '4' in stage else '•')
            conf = s.get('confidence') or 0
            dot = "🔵" if conf>=2.5 else ("🟢" if conf>=1.2 else "⚪")
            st.markdown(f"<div class='card' style='margin-bottom:8px'>{icon} <b>{s['symbol']}</b> · {stage} <span style='float:right'>{dot}</span><br><span style='color:var(--muted);font-size:12px'>{s['ts']}</span></div>", unsafe_allow_html=True)

# Right content — Symbol Check
with right:
    st.subheader('Symbol Check')
    colA,colB = st.columns([0.6,0.4])
    with colA:
        symbol = st.text_input('Symbol', value='BTC/USDT')
    with colB:
        try:
            m = requests.get(f"{API_BASE}/momentum", params={'symbol': symbol}, timeout=6).json()
            bucket = (m.get('bucket') or 'low').lower()
            label = 'LOW' if bucket=='low' else ('MEDIUM' if bucket=='medium' else 'STRONG')
            st.markdown(f"<span class='badge {'low' if bucket=='low' else ('medium' if bucket=='medium' else 'strong')}'>MOMENTUM: {label}</span>", unsafe_allow_html=True)
        with st.expander("AIXBT details"):
            try:
                mt = requests.get(f"{API_BASE}/momentum/trend", params={'symbol': symbol, 'days': 7}, timeout=8).json()
                ser = mt.get('series', [])
                if ser:
                    import pandas as pd, altair as alt
                    s = pd.DataFrame(ser)
                    s['ts'] = pd.to_datetime(s['ts'], utc=True, errors='coerce')
                    spark = alt.Chart(s).mark_line(color='#2ec7a1').encode(x='ts:T', y='score:Q')
                    st.altair_chart(spark.properties(height=120).configure_axis(grid=False).configure_view(strokeOpacity=0), use_container_width=True)
                else:
                    st.caption('No momentum series available.')
            except Exception as e:
                st.caption('No momentum series available.')
        
        except Exception:
            st.markdown("<span class='badge'>MOMENTUM: LOW</span>", unsafe_allow_html=True)

    # (Charts can be wired to DB series in your environment)
    import numpy as np
    dx = pd.DataFrame({'timestamp': pd.date_range('2024-01-01', periods=120, freq='D'),'close': 100+np.cumsum(np.random.randn(120))})
    
st.altair_chart(alt.Chart(dx).mark_line(color='#9ad2ff').encode(x='timestamp:T', y='close:Q').properties(height=280).configure_axis(grid=False).configure_view(strokeOpacity=0), use_container_width=True)
# Stage tag (last signal)
try:
    stg = requests.get(f"{API_BASE}/signals/recent", params={'symbol': symbol, 'limit': 1}, timeout=6).json()
    if isinstance(stg, list) and stg:
        stage_txt = stg[0].get('stage','Neutral')
        color_cls = 'pos' if '2' in stage_txt else ('neg' if '4' in stage_txt else 'info')
        st.markdown(f"<div style='text-align:right;margin-top:-8px'><span class='badge' style='border-color:transparent;background:transparent;color:var(--{color_cls});font-weight:600'>{stage_txt}</span></div>", unsafe_allow_html=True)
except Exception:
    pass

    try:
        lu = requests.get(f"{API_BASE}/last_updated", params={'symbol': symbol}, timeout=4).json()
        ts_txt = lu.get('ts') or 'n/a'
        try:
        from datetime import datetime
        lt = datetime.fromisoformat((ts_txt or '').replace('Z','+00:00')).astimezone().strftime('%Y-%m-%d %H:%M:%S') if ts_txt else 'n/a'
        st.caption(f"Last updated: {lt} (local) · UTC: {ts_txt}")
    if '/' not in symbol:
        try:
            nb = requests.get(f"{API_BASE}/stocks/nbbo/spark", params={'ticker': symbol, 'lookback_min': 60, 'metric':'spread_bps'}, timeout=8).json()
            r = nb.get('rows', [])
            if r:
                import pandas as pd, altair as alt
                q = pd.DataFrame(r)
                q['ts'] = pd.to_datetime(q['ts'])
                sp = alt.Chart(q).mark_line(color='#ffb14a').encode(x='ts:T', y='spread_bps:Q')
                st.altair_chart(sp.properties(height=120).configure_axis(grid=False).configure_view(strokeOpacity=0), use_container_width=True)
                
metric_label = st.selectbox('NBBO metric', ['Spread (bps)', 'Midprice (USD)'], index=0, key='nbbo_metric')
y_col = 'spread_bps' if metric_label.startswith('Spread') else 'mid'
color = '#ffb14a' if y_col=='spread_bps' else '#67a5ff'
sp = alt.Chart(q).mark_line(color=color).encode(x='ts:T', y=alt.Y(f'{y_col}:Q'))
st.altair_chart(sp.properties(height=120).configure_axis(grid=False).configure_view(strokeOpacity=0), use_container_width=True)
st.caption('NBBO ' + ('Spread (bps)' if y_col=='spread_bps' else 'Midprice (USD)') + ', last 60 min')

# Mini tape (latest trades)
try:
    tape = requests.get(f"{API_BASE}/stocks/tape", params={'ticker': symbol, 'limit': 20}, timeout=6).json()
    rows = tape.get('rows', [])
    if rows:
        import pandas as pd
        tdf = pd.DataFrame(rows)
        tdf['ts'] = pd.to_datetime(tdf['ts']).dt.strftime('%H:%M:%S')
        st.dataframe(tdf[['ts','price','size']], hide_index=True, use_container_width=True)
    else:
        st.caption('Mini tape: no prints in window.')
except Exception:
    st.caption('Mini tape: unavailable.')

            
            else:
                st.caption('NBBO: no data in last hour.')
        except Exception:
            st.caption('NBBO: unavailable.')
    
    except Exception:
        st.caption(f"Last updated (UTC): {ts_txt}")
    except Exception:
        st.caption("Last updated: n/a")

    c1,c2 = st.columns(2)
    with c1:
        dx['obv']=np.cumsum(np.random.randn(120))
        st.altair_chart(alt.Chart(dx).mark_line(color='#7ce8c7').encode(x='timestamp:T', y='obv:Q').properties(height=160).configure_axis(grid=False).configure_view(strokeOpacity=0), use_container_width=True)
    with c2:
        dx['ad']=np.cumsum(np.random.randn(120))
        st.altair_chart(alt.Chart(dx).mark_line(color='#c8d0ff').encode(x='timestamp:T', y='ad:Q').properties(height=160).configure_axis(grid=False).configure_view(strokeOpacity=0), use_container_width=True)

# pages (placeholder for runbook UI)
os.makedirs('pages', exist_ok=True)
