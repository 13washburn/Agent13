import pandas as pd
import numpy as np

def add_obv_ad(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out = out.dropna(subset=["close","volume"])  
    close = out["close"]
    vol = out["volume"].fillna(0)
    direction = np.sign(close.diff()).fillna(0)
    obv = (direction * vol).cumsum()
    out["obv"] = obv
    high = out["high"]; low = out["low"]
    clv = ( (close - low) - (high - close) ) / ( (high - low).replace(0, np.nan) )
    clv = clv.fillna(0)
    ad = (clv * vol).cumsum()
    out["ad"] = ad
    out["obv_slope"] = out["obv"].diff(6)
    out["ad_slope"]  = out["ad"].diff(6)
    return out
