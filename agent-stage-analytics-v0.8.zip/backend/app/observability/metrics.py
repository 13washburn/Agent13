from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
import time

REQS = Counter('api_requests_total', 'Total API requests', ['path','method','status'])
LAT  = Histogram('api_request_latency_seconds', 'Latency', ['path','method'])
UP   = Gauge('service_up', '1 if service is up')
UP.set(1)

class MetricsMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start = time.time()
        response = await call_next(request)
        dur = time.time() - start
        path = request.url.path
        method = request.method
        REQS.labels(path, method, str(response.status_code)).inc()
        LAT.labels(path, method).observe(dur)
        return response

def metrics_endpoint():
    data = generate_latest()
    return Response(content=data, media_type=CONTENT_TYPE_LATEST)
