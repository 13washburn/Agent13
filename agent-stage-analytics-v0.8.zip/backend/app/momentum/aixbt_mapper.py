import time
from typing import Dict, Optional
from ..ingestion.aixbt_client import AIXBT

_cache = { 'ts': 0, 'projects': [] }
SYMBOL_HINTS = { 'BTC': ['bitcoin','btc'], 'ETH': ['ethereum','eth'] }

class MomentumService:
    def __init__(self, client: Optional[AIXBT] = None):
        self.client = client or AIXBT()

    def _refresh(self):
        now = time.time()
        if now - _cache['ts'] < 300 and _cache['projects']:
            return
        try:
            page=1; allp=[]
            while True:
                resp = self.client.projects(page=page, limit=50)
                data = resp.get('data', []) if isinstance(resp, dict) else resp.get('projects', [])
                if not data: break
                allp += data
                if not resp.get('pagination',{}).get('hasMore'): break
                page+=1
            _cache['ts'] = now
            _cache['projects'] = allp
        except Exception:
            pass

    def map_symbol(self, symbol: str) -> Optional[Dict]:
        self._refresh()
        base = symbol.split('/') [0].upper()
        candidates = SYMBOL_HINTS.get(base, [base.lower()])
        for p in _cache['projects']:
            name = (p.get('name') or p.get('title') or '').lower()
            for c in candidates:
                if c in name:
                    return p
        return None

    def momentum_score(self, project_id: str) -> Optional[float]:
        try:
            m = self.client.momentum(project_id)
            if isinstance(m, dict) and 'data' in m and isinstance(m['data'], dict):
                s = m['data'].get('score') or m['data'].get('momentum')
                if isinstance(s, (int, float)): return float(s)
            if isinstance(m, dict) and 'values' in m and isinstance(m['values'], list) and m['values']:
                last = m['values'][-1]
                if isinstance(last, dict):
                    return float(last.get('score') or last.get('momentum') or 0)
        except Exception:
            return None
        return None
