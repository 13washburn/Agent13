
import os, json, asyncio
import websockets
from datetime import datetime, timezone
from sqlalchemy.dialects.postgresql import insert
from ..db.database import SessionLocal
from ..db.models import Base
from sqlalchemy import text as sa_text

API_KEY = os.getenv('POLYGON_API_KEY', '')
TICKERS = [t.strip().upper() for t in os.getenv('EQUITY_TICKERS','AAPL,MSFT').split(',') if t.strip()]
BASE_WS = os.getenv('POLYGON_WS_BASE', 'wss://socket.polygon.io/stocks')

async def save_trade(m):
    db = SessionLocal()
    try:
        ts = datetime.fromtimestamp(int(m.get('t', 0))/1000.0, tz=timezone.utc)
        price = float(m.get('p', 0))
        size = float(m.get('s', 0))
        sym = m.get('sym') or m.get('S') or ''
        conditions = m.get('c')
        db.execute(sa_text("""
            INSERT INTO stock_trades(sym, ts, price, size, conditions)
            VALUES (:sym, :ts, :price, :size, :conditions)
            ON CONFLICT (sym, ts) DO NOTHING
        """), dict(sym=sym, ts=ts, price=price, size=size, conditions=json.dumps(conditions) if conditions is not None else None))
        db.commit()
    finally:
        db.close()

async def save_quote(m):
    db = SessionLocal()
    try:
        ts = datetime.fromtimestamp(int(m.get('t', 0))/1000.0, tz=timezone.utc)
        ap = float(m.get('ap', 0))
        asz = float(m.get('as', 0))
        bp = float(m.get('bp', 0))
        bsz = float(m.get('bs', 0))
        sym = m.get('sym') or ''
        db.execute(sa_text("""
            INSERT INTO stock_quotes(sym, ts, bid, bidsz, ask, asksz)
            VALUES (:sym, :ts, :bp, :bsz, :ap, :asz)
            ON CONFLICT (sym, ts) DO NOTHING
        """), dict(sym=sym, ts=ts, bp=bp, bsz=bsz, ap=ap, asz=asz))
        db.commit()
    finally:
        db.close()

async def run():
    if not API_KEY:
        print('[polygon_tq] POLYGON_API_KEY not set; exiting.')
        return
    subs = ','.join([*(f'T.{t}' for t in TICKERS), *(f'Q.{t}' for t in TICKERS)])
    backoff = 1
    while True:
        try:
            async with websockets.connect(BASE_WS, ping_interval=20, ping_timeout=20) as ws:
                await ws.send(json.dumps({"action":"auth","params": API_KEY}))
                await asyncio.sleep(0.5)
                await ws.send(json.dumps({"action":"subscribe","params": subs}))
                backoff = 1
                while True:
                    raw = await ws.recv()
                    try:
                        data = json.loads(raw)
                    except Exception:
                        continue
                    msgs = data if isinstance(data, list) else [data]
                    for m in msgs:
                        ev = m.get('ev')
                        if ev == 'T':
                            await save_trade(m)
                        elif ev == 'Q':
                            await save_quote(m)
        except Exception as e:
            await asyncio.sleep(backoff)
            backoff = min(backoff*2, 60)

if __name__ == '__main__':
    asyncio.run(run())
