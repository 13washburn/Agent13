import asyncio, json, os
from datetime import datetime, timezone
import websockets
from prometheus_client import CollectorRegistry, Counter, push_to_gateway
REG = CollectorRegistry()
WS_MSG = Counter('ws_messages_total', 'WS messages processed', ['stream','type'], registry=REG)
PUSHGW = os.getenv('PUSHGATEWAY_URL','http://pushgateway:9091')
_msg_tick = 0
from sqlalchemy.dialects.postgresql import insert
from ..db.database import SessionLocal
from ..db.models import Bar

# Maps 'BTC/USDT' -> 'btcusdt@kline_1m'
def sym_to_stream(sym: str) -> str:
    s = sym.replace('/', '').lower()
    return f"{s}@kline_1m"

BINANCE_WS = "wss://stream.binance.com:9443/stream"
SYMS = os.getenv('CRYPTO_SYMBOLS', 'BTC/USDT,ETH/USDT').split(',')
STREAMS = '/'.join([sym_to_stream(s.strip()) for s in SYMS])

async def save_kline(msg: dict):
    if 'data' not in msg: return
    d = msg['data']
    if d.get('e') != 'kline':
        return
    k = d['k']
    symbol = d.get('s', '').replace('USDT', '/USDT')
    close_time = datetime.fromtimestamp(k['T']/1000, tz=timezone.utc)
    o,h,l,c,v = float(k['o']), float(k['h']), float(k['l']), float(k['c']), float(k['v'])
    if not k['x']:
        return
    db = SessionLocal()
    try:
        stmt = insert(Bar).values(symbol=symbol, venue='binance', timeframe='1m', ts=close_time,
                                  open=o, high=h, low=l, close=c, volume=v)
        stmt = stmt.on_conflict_do_nothing(index_elements=['symbol','timeframe','ts'])
        db.execute(stmt)
        db.commit()
    finally:
        db.close()

async def run():
    url = f"{BINANCE_WS}?streams={STREAMS}"
    backoff = 1
    while True:
        try:
            async with websockets.connect(url, ping_interval=20, ping_timeout=20) as ws:
                backoff = 1
                while True:
                    raw = await ws.recv()
                    msg = json.loads(raw)
                    WS_MSG.labels('binance','kline').inc(); _msg_tick += 1
                    if _msg_tick % 20 == 0:
                        try:
                            push_to_gateway(PUSHGW, job='ws', registry=REG)
                        except Exception:
                            pass
                    await save_kline(msg)
        except Exception:
            await asyncio.sleep(backoff)
            backoff = min(backoff*2, 60)

if __name__ == '__main__':
    asyncio.run(run())
