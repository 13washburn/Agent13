from abc import ABC, abstractmethod
from typing import Dict

class Publisher(ABC):
    @abstractmethod
    def publish(self, payload: Dict) -> bool:
        ...
