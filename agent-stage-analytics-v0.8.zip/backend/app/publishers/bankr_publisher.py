import os, json, requests
from typing import Dict
from .publisher_base import Publisher

class BankrPublisher(Publisher):
    def __init__(self):
        self.url = os.getenv('BANKR_WEBHOOK_URL', '')
        self.key = os.getenv('BANKR_API_KEY', '')

    def publish(self, payload: Dict) -> bool:
        if not self.url:
            return False
        headers = {'Content-Type':'application/json'}
        if self.key:
            headers['Authorization'] = f"Bearer {self.key}"
        try:
            r = requests.post(self.url, data=json.dumps(payload), headers=headers, timeout=10)
            return r.status_code//100 == 2
        except Exception:
            return False
