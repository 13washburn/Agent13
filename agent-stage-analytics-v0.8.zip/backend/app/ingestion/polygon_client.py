import os
import requests
import pandas as pd
from datetime import datetime, timedelta

BASE = "https://api.polygon.io"
API_KEY = os.getenv("POLYGON_API_KEY", "")

def fetch_polygon_ohlcv(ticker: str, timespan: str = "day", limit: int = 500) -> pd.DataFrame:
    if not API_KEY:
        return pd.DataFrame(columns=["open","high","low","close","volume"])    
    to_date = datetime.utcnow().date()
    from_date = to_date - timedelta(days=limit*2)
    url = f"{BASE}/v2/aggs/ticker/{ticker}/range/1/{timespan}/{from_date}/{to_date}?adjusted=true&sort=asc&limit={limit}&apiKey={API_KEY}"
    r = requests.get(url, timeout=30)
    r.raise_for_status()
    data = r.json()
    results = data.get('results', [])
    if not results:
        return pd.DataFrame(columns=["open","high","low","close","volume"])    
    df = pd.DataFrame(results)
    df = df.rename(columns={"o":"open","h":"high","l":"low","c":"close","v":"volume","t":"timestamp"})
    df = df[["timestamp","open","high","low","close","volume"]].set_index("timestamp")
    df.index = pd.to_datetime(df.index, unit='ms')
    return df
