import ccxt
import pandas as pd

def fetch_ccxt_ohlcv(symbol: str = "BTC/USDT", timeframe: str = "1d", limit: int = 500, exchange_id: str = "binance") -> pd.DataFrame:
    ex = getattr(ccxt, exchange_id)()
    ex.load_markets()
    ohlcv = ex.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
    df = pd.DataFrame(ohlcv, columns=["timestamp","open","high","low","close","volume"]).set_index("timestamp")
    df.index = pd.to_datetime(df.index, unit='ms')
    return df
