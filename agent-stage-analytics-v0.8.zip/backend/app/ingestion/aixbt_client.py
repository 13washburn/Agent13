import os
import requests

API = "https://api.aixbt.tech/v2"
AIXBT_KEY = os.getenv("AIXBT_API_KEY", "")

class AIXBT:
    def __init__(self, api_key: str | None = None):
        self.key = api_key or AIXBT_KEY
        self.headers = {"x-api-key": self.key} if self.key else {}

    def projects(self, page: int = 1, limit: int = 50):
        r = requests.get(f"{API}/projects?page={page}&limit={limit}", headers=self.headers, timeout=30)
        r.raise_for_status(); return r.json()

    def momentum(self, project_id: str):
        r = requests.get(f"{API}/projects/{project_id}/momentum", headers=self.headers, timeout=30)
        r.raise_for_status(); return r.json()
