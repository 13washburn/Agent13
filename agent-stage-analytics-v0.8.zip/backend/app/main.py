from fastapi import FastAPI, Query
from .ingestion.ccxt_client import fetch_ccxt_ohlcv
from .ingestion.polygon_client import fetch_polygon_ohlcv
from .ingestion.aixbt_client import AIXBT
from .detection.stage_analysis import label_stages
from .detection.indicators import add_obv_ad
from .db.database import SessionLocal
from .db.models import Bar, Signal
from sqlalchemy import select
from .observability.metrics import MetricsMiddleware, metrics_endpoint
from .momentum.aixbt_mapper import MomentumService

app = FastAPI(title="Agent Stage Analytics API", version="0.3.0")
app.add_middleware(MetricsMiddleware)
app.add_api_route('/metrics', metrics_endpoint, methods=['GET'])

aixbt = AIXBT()
_mom = MomentumService(aixbt)

@app.get("/health")
def health():
    return {"ok": True}

@app.get("/signals/example")
def signals_example(symbol: str = Query(default="BTC/USDT"), timeframe: str = Query(default="1d"), limit: int = 500):
    momentum_meta = {"project": None, "score": None}
    df = fetch_ccxt_ohlcv(symbol=symbol, timeframe=timeframe, limit=limit)
    df = add_obv_ad(df)
    labeled = label_stages(df)
    labeled["confidence"] = labeled[["rvol10"]].fillna(0).clip(0,3)
    pj = _mom.map_symbol(symbol)
    if pj and pj.get('id'):
        momentum_meta = {"project": pj, "score": None}
        ms = _mom.momentum_score(pj['id'])
        if ms is not None:
            momentum_meta["score"] = float(ms)
            labeled['confidence'] = (labeled['confidence'] + min(ms/100.0, 0.5)).clip(0, 3.5)
    return {"symbol": symbol, "timeframe": timeframe, "momentum": momentum_meta, "rows": labeled.tail(50).reset_index().to_dict(orient="records")}

@app.get("/signals/polygon")
def signals_polygon(ticker: str = Query(..., description="US equity ticker, e.g., AAPL"), timespan: str = Query("day"), limit: int = 500):
    df = fetch_polygon_ohlcv(ticker=ticker, timespan=timespan, limit=limit)
    df = add_obv_ad(df)
    labeled = label_stages(df)
    labeled["confidence"] = labeled[["rvol10"]].fillna(0).clip(0,3)
    return {"ticker": ticker, "timespan": timespan, "rows": labeled.tail(50).reset_index().to_dict(orient="records")}

@app.get("/signals/recent")
def signals_recent(symbol: str, limit: int = 50):
    db = SessionLocal()
    try:
        rows = db.execute(select(Signal).where(Signal.symbol==symbol).order_by(Signal.ts.desc()).limit(limit)).scalars().all()
        return [{
            'symbol': r.symbol,
            'ts': r.ts.isoformat(),
            'stage': r.stage,
            'confidence': r.confidence,
            'rvol10': r.rvol10,
            'obv_slope': r.obv_slope,
            'ad_slope': r.ad_slope,
            'extras': r.extras
        } for r in rows]
    finally:
        db.close()


from fastapi import HTTPException
from datetime import datetime, timedelta, timezone

@app.get("/stocks/nbbo")
def stocks_nbbo(ticker: str, lookback_min: int = 30):
    """Return NBBO time series (bid, ask, spread) for the past N minutes from stock_quotes."""
    db = SessionLocal()
    try:
        since = datetime.now(tz=timezone.utc) - timedelta(minutes=lookback_min)
        rows = db.execute(
            select(Bar.ts)  # dummy select then raw SQL for quotes
        )  # placeholder to keep import usage
        sql = (
            "SELECT ts, bid, bidsz, ask, asksz FROM stock_quotes "
            "WHERE sym=:sym AND ts >= :since ORDER BY ts ASC"
        )
        data = db.execute(sql, { 'sym': ticker.upper(), 'since': since }).fetchall()
        if not data:
            return { 'ticker': ticker.upper(), 'rows': [] }
        out = []
        for (ts, bid, bidsz, ask, asksz) in data:
            spread = (ask or 0) - (bid or 0)
            out.append({ 'timestamp': ts.isoformat(), 'bid': bid, 'ask': ask, 'spread': spread, 'bidsz': bidsz, 'asksz': asksz })
        return { 'ticker': ticker.upper(), 'rows': out }
    finally:
        db.close()

@app.get("/stocks/tape")
def stocks_tape(ticker: str, limit: int = 100):
    """Return recent trades (price, size, ts) from stock_trades."""
    limit = max(1, min(limit, 1000))
    db = SessionLocal()
    try:
        sql = (
            "SELECT ts, price, size FROM stock_trades "
            "WHERE sym=:sym ORDER BY ts DESC LIMIT :lim"
        )
        data = db.execute(sql, { 'sym': ticker.upper(), 'lim': limit }).fetchall()
        out = [ { 'timestamp': ts.isoformat(), 'price': float(price or 0), 'size': float(size or 0) } for (ts, price, size) in data ]
        return { 'ticker': ticker.upper(), 'rows': out }
    finally:
        db.close()
