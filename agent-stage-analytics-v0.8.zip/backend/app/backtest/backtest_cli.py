import argparse, pandas as pd
from sqlalchemy import select
from ..db.database import SessionLocal
from ..db.models import Bar
from ..detection.indicators import add_obv_ad
from ..detection.stage_analysis import label_stages

def load_bars(symbol: str):
    db = SessionLocal()
    try:
        rows = db.execute(select(Bar).where(Bar.symbol==symbol).order_by(Bar.ts.asc())).scalars().all()
        if not rows: return pd.DataFrame()
        df = pd.DataFrame([
            {'timestamp': r.ts, 'open': r.open, 'high': r.high, 'low': r.low, 'close': r.close, 'volume': r.volume}
        for r in rows]).set_index('timestamp')
        return df
    finally:
        db.close()


def run(symbol: str):
    df = load_bars(symbol)
    if df.empty:
        print("No bars for", symbol); return
    df = add_obv_ad(df)
    lab = label_stages(df)
    pos = 0; entry=0; pnl=0; trades=[]
    for ts, row in lab.iterrows():
        if pos==0 and row['stage']=='Stage 2':
            pos=1; entry=row['close']; trades.append((ts,'BUY',entry))
        elif pos==1 and row['stage']=='Stage 4':
            pos=0; exitp=row['close']; trades.append((ts,'SELL',exitp)); pnl += (exitp-entry)/entry
    if pos==1:
        exitp=lab.iloc[-1]['close']; trades.append((lab.index[-1],'SELL',exitp)); pnl += (exitp-entry)/entry
    print(f"{symbol}: trades={len(trades)} total_return={pnl*100:.2f}%")
    for t in trades[:10]:
        print(t)

if __name__=='__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--symbol', required=True)
    run(ap.parse_args().symbol)
