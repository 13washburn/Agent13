import os, time, smtplib, requests
from email.mime_text import MIMEText
from sqlalchemy import select
from ..db.database import SessionLocal
from ..db.models import Signal

EMAIL_TO = os.getenv('ALERT_EMAIL_TO')
SMTP_HOST = os.getenv('SMTP_HOST')
SMTP_PORT = int(os.getenv('SMTP_PORT','587'))
SMTP_USER = os.getenv('SMTP_USER')
SMTP_PASS = os.getenv('SMTP_PASS')
TG_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
TG_CHAT  = os.getenv('TELEGRAM_CHAT_ID')

_seen = set()

def send_email(subj: str, body: str):
    if not (EMAIL_TO and SMTP_HOST and SMTP_USER and SMTP_PASS):
        return
    msg = MIMEText(body)
    msg['Subject'] = subj
    msg['From'] = SMTP_USER
    msg['To'] = EMAIL_TO
    with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as s:
        s.starttls(); s.login(SMTP_USER, SMTP_PASS); s.sendmail(SMTP_USER, [EMAIL_TO], msg.as_string())

def send_tg(text: str):
    if not (TG_TOKEN and TG_CHAT):
        return
    url = f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage"
    try:
        requests.post(url, json={'chat_id': TG_CHAT, 'text': text}, timeout=10)
    except Exception:
        pass

while True:
    db = SessionLocal()
    try:
        rows = db.execute(select(Signal).order_by(Signal.id.desc()).limit(50)).scalars().all()
        for r in rows:
            if r.id in _seen: continue
            _seen.add(r.id)
            if r.stage in ('Stage 2','Stage 4') and (r.confidence or 0) >= 1.0:
                text = f"{r.symbol} → {r.stage}  conf={r.confidence:.2f}  rvol10={r.rvol10:.2f}"
                send_email(f"Signal: {r.symbol} {r.stage}", text)
                send_tg(text)
    finally:
        db.close()
    time.sleep(15)
