import asyncio
import os
import pandas as pd
from sqlalchemy.dialects.postgresql import insert

from prometheus_client import CollectorRegistry, Counter, push_to_gateway
REG = CollectorRegistry()
C_INGEST = Counter('ingest_bars_total', 'Bars ingested', ['source','symbol','timeframe'], registry=REG)
PUSHGW = os.getenv('PUSHGATEWAY_URL','http://pushgateway:9091')

from ..db.database import SessionLocal
from ..db.models import Bar
from ..ingestion.ccxt_client import fetch_ccxt_ohlcv
from ..ingestion.polygon_client import fetch_polygon_ohlcv

CRYPTO_SYMBOLS = os.getenv('CRYPTO_SYMBOLS', 'BTC/USDT,ETH/USDT').split(',')
EQUITY_TICKERS = os.getenv('EQUITY_TICKERS', 'AAPL,MSFT').split(',')

async def save_bars(df: pd.DataFrame, symbol: str, timeframe: str, venue: str|None=None):
    if df is None or df.empty: return
    df = df.copy().dropna(subset=['open','high','low','close','volume'])
    df['ts'] = pd.to_datetime(df.index, utc=True)
    records = [
        dict(symbol=symbol, venue=venue, timeframe=timeframe, ts=row['ts'].to_pydatetime(),
             open=row['open'], high=row['high'], low=row['low'], close=row['close'], volume=row['volume'])
        for _, row in df.iterrows()
    ]
    if not records: return
    db = SessionLocal()
    try:
        stmt = insert(Bar).values(records)
        stmt = stmt.on_conflict_do_nothing(index_elements=['symbol','timeframe','ts'])
        db.execute(stmt)
        db.commit()
    finally:
        db.close()

async def loop_crypto():
    while True:
        for sym in CRYPTO_SYMBOLS:
            df = fetch_ccxt_ohlcv(sym, timeframe='1h', limit=200)
            await save_bars(df, sym, '1h', venue='binance')
            try:
                C_INGEST.labels('ccxt','{sym}','1h').inc(len(df))
                push_to_gateway(PUSHGW, job='ingest', registry=REG)
            except Exception:
                pass
        await asyncio.sleep(60)

async def loop_equities():
    while True:
        for t in EQUITY_TICKERS:
            df = fetch_polygon_ohlcv(ticker=t, timespan='minute', limit=200)
            await save_bars(df, t, '1m', venue='polygon')
            try:
                C_INGEST.labels('polygon_rest','{t}','1m').inc(len(df))
                push_to_gateway(PUSHGW, job='ingest', registry=REG)
            except Exception:
                pass
        await asyncio.sleep(60)

async def main():
    await asyncio.gather(loop_crypto(), loop_equities())

if __name__ == '__main__':
    asyncio.run(main())
