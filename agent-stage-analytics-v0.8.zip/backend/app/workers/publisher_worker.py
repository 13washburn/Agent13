import time
from sqlalchemy import select
from ..db.database import SessionLocal
from ..db.models import Signal
from ..publishers.bankr_publisher import BankrPublisher

PUB = BankrPublisher()
_seen = set()

while True:
    db = SessionLocal()
    try:
        rows = db.execute(select(Signal).order_by(Signal.id.desc()).limit(100)).scalars().all()
        for r in rows:
            if r.id in _seen: continue
            if r.stage not in ('Stage 2','Stage 4'): continue
            payload = {
                'symbol': r.symbol,
                'stage': r.stage,
                'confidence': r.confidence,
                'rvol10': r.rvol10,
                'obv_slope': r.obv_slope,
                'ad_slope': r.ad_slope,
                'ts': r.ts.isoformat()
            }
            if PUB.publish(payload):
                _seen.add(r.id)
    finally:
        db.close()
    time.sleep(10)
