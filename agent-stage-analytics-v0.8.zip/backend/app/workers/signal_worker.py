import time
import pandas as pd
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert

from prometheus_client import CollectorRegistry, Counter, push_to_gateway
REG = CollectorRegistry()
C_SIG = Counter('signals_total', 'Signals generated', ['stage','symbol'], registry=REG)
PUSHGW = os.getenv('PUSHGATEWAY_URL','http://pushgateway:9091')

from ..db.database import SessionLocal
from ..db.models import Bar, Signal
from ..detection.indicators import add_obv_ad
from ..detection.stage_analysis import label_stages
from ..momentum.aixbt_mapper import MomentumService

MOM = MomentumService()

def fetch_symbols(db):
    return db.execute(select(Bar.symbol).distinct()).scalars().all()

while True:
    db = SessionLocal()
    try:
        symbols = fetch_symbols(db)
        for sym in symbols:
            rows = db.execute(select(Bar).where(Bar.symbol==sym).order_by(Bar.ts.asc())).scalars().all()
            if not rows:
                continue
            df = pd.DataFrame([
                { 'timestamp': r.ts, 'open': r.open, 'high': r.high, 'low': r.low, 'close': r.close, 'volume': r.volume }
                for r in rows
            ]).set_index('timestamp')
            df = add_obv_ad(df)
            labeled = label_stages(df)
            labeled['confidence'] = labeled['rvol10'].clip(lower=0, upper=3).fillna(0)
            pj = MOM.map_symbol(sym)
            if pj and pj.get('id'):
                ms = MOM.momentum_score(pj['id'])
                if ms is not None:
                    labeled['confidence'] = (labeled['confidence'] + min(ms/100.0, 0.5)).clip(0, 3.5)
            labeled = labeled.tail(5)
            for ts, row in labeled.iterrows():
                stmt = insert(Signal).values(
                    symbol=sym, ts=ts, stage=row['stage'], confidence=float(row.get('confidence',0) or 0),
                    rvol10=float(row.get('rvol10',0) or 0), obv_slope=float(row.get('obv_slope',0) or 0),
                    ad_slope=float(row.get('ad_slope',0) or 0), extras=None
                ).on_conflict_do_nothing(index_elements=['symbol','ts','stage'])
                db.execute(stmt)
        db.commit()
            try:
                # increment counters for last few labeled rows
                for ts, row in labeled.iterrows():
                    if row.get('stage') in ('Stage 2', 'Stage 4'):
                        C_SIG.labels(row.get('stage'), sym).inc()
                push_to_gateway(PUSHGW, job='signals', registry=REG)
            except Exception:
                pass
    except Exception:
        db.rollback()
    finally:
        db.close()
    time.sleep(30)
