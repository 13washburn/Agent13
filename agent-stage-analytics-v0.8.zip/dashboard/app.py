import os
import requests
import streamlit as st
import pandas as pd

API_BASE = os.getenv("API_BASE", "http://localhost:8000")

st.set_page_config(page_title="Agent Stage Analytics", layout="wide")
st.title("Agent Stage Analytics — Live Research Dashboard")

st.caption("Analytics-only. Not financial advice.")

with st.sidebar:
    st.header("Recent Signals")
    sym = st.text_input("Symbol for feed", value="BTC/USDT")
    if st.button("Refresh Feed"):
        try:
            r = requests.get(f"{API_BASE}/signals/recent", params={"symbol": sym, "limit": 25}, timeout=20)
            sigs = r.json()
            st.session_state['feed'] = sigs
        except Exception as e:
            st.error(f"Failed to load signals: {e}")
    feed = st.session_state.get('feed', [])
    if feed:
        for s in feed:
            st.write(f"{s['ts']} — **{s['symbol']}** : :orange[{s['stage']}]  conf={s.get('confidence',0):.2f}")

col1, col2 = st.columns(2)
with col1:
    st.subheader("Crypto (CCXT demo)")
    symbol = st.text_input("Symbol", value="BTC/USDT")
    tf = st.selectbox("Timeframe", ["1h","4h","1d"], index=2)
    if st.button("Run (Crypto)"):
        r = requests.get(f"{API_BASE}/signals/example", params={"symbol": symbol, "timeframe": tf, "limit": 500}, timeout=60)
        data = r.json()
        df = pd.DataFrame(data.get("rows", []))
        st.dataframe(df.tail(20))
        if not df.empty:
            st.line_chart(df.set_index("timestamp")["close"], height=200)
            st.area_chart(df.set_index("timestamp")["obv"], height=150)
            st.area_chart(df.set_index("timestamp")["ad"], height=150)

with col2:
    st.subheader("US Stocks (Polygon)")
    ticker = st.text_input("Ticker", value="AAPL")
    if st.button("Run (Equities)"):
        r = requests.get(f"{API_BASE}/signals/polygon", params={"ticker": ticker, "timespan": "day", "limit": 500}, timeout=60)
        data = r.json()
        df = pd.DataFrame(data.get("rows", []))
        if df.empty:
            st.warning("No data returned. Did you set POLYGON_API_KEY?")
        st.dataframe(df.tail(20))
        if not df.empty:
            st.line_chart(df.set_index("timestamp")["close"], height=200)
            st.area_chart(df.set_index("timestamp")["obv"], height=150)
            st.area_chart(df.set_index("timestamp")["ad"], height=150)

st.divider()
st.write("Momentum badges and execution previews coming next.")



st.subheader("US Stocks (Live NBBO & Tape)")
lticker = st.text_input("Live ticker (NBBO & Tape)", value="AAPL")
col_nbbo, col_tape = st.columns(2)
with col_nbbo:
    lookback = st.slider("Lookback (minutes)", min_value=5, max_value=240, value=60, step=5)
    if st.button("Load NBBO"):
        r = requests.get(f"{API_BASE}/stocks/nbbo", params={"ticker": lticker, "lookback_min": lookback}, timeout=30)
        data = r.json()
        rows = data.get("rows", [])
        if rows:
            nd = pd.DataFrame(rows).set_index("timestamp")
            st.line_chart(nd[["bid","ask","spread"]], height=250)
        else:
            st.info("No NBBO data in the selected window.")
with col_tape:
    lim = st.slider("Tape size", min_value=20, max_value=500, value=100, step=20)
    if st.button("Load Tape"):
        r = requests.get(f"{API_BASE}/stocks/tape", params={"ticker": lticker, "limit": lim}, timeout=30)
        data = r.json(); rows = data.get("rows", [])
        if rows:
            td = pd.DataFrame(rows)
            st.dataframe(td)
        else:
            st.info("No recent trades.")
