# Agent Stage Analytics (Research Agent)

> Live, **analytics-only** AI agent that detects **Weinstein Stage‑2 breakouts**, **Stage‑4 downtrends**, **buy/sell pressure**, and **volume anomalies** across **crypto** and **US stocks**, with a live dashboard and REST API. *No live trading; paper/publish-only by default.*

## What you get (v0.3)
- **Real-time crypto** via **Binance WebSocket** (1m klines) → DB (Timescale).
- **AIXBT momentum overlay**: symbol→project mapping + momentum score → confidence boost.
- **On‑chain publishing (read‑only)** via **Bankr publisher stub** (webhook-based) for verifiable signal streams.
- **Production hardening**: Prometheus `/metrics`, structured metrics middleware, and tighter defaults.

## Quick start

### 1) Prereqs
- Docker & Docker Compose

### 2) Configure env
```bash
cp .env.example .env
# optional keys
# POLYGON_API_KEY=            # stocks
# AIXBT_API_KEY=              # momentum overlay
# BANKR_WEBHOOK_URL=          # on-chain publishing via Bankr webhook
# BANKR_API_KEY=
# ALERT_EMAIL_TO= SMTP_HOST= SMTP_PORT= SMTP_USER= SMTP_PASS=
# TELEGRAM_BOT_TOKEN= TELEGRAM_CHAT_ID=
# CRYPTO_SYMBOLS=BTC/USDT,ETH/USDT
# EQUITY_TICKERS=AAPL,MSFT
```

### 3) Run
```bash
docker compose up --build
```
- API: http://localhost:8000/docs
- Metrics: http://localhost:8000/metrics
- Dashboard: http://localhost:8501

### 4) Backtest example
```bash
docker compose run --rm api python -m app.backtest.backtest_cli --symbol BTC/USDT
```

## Services
- `db` (Timescale/Postgres) – bars & signals hypertables
- `api` (FastAPI) – REST API + momentum overlay + /metrics
- `ingest` – CCXT/Polygon REST ingestion loop
- `wscrypto` – Binance WebSocket (1m klines closed) → DB
- `signals` – Stage/pressure engine → signals table
- `alerts` – Email/Telegram (optional)
- `publisher` – read‑only signal publisher (Bankr webhook)
- `dashboard` – Streamlit UI

## Notes
- Stage Analysis: 30‑period SMA baseline w/ volume confirmation (weekly intent; works on daily/intraday too). Thresholds in `app/detection/*`.
- OBV & A/D used for buy/sell pressure and divergences.
- Polygon (stocks) is optional; without key you’ll still get crypto working.
- Publishing is **read‑only** (no execution) and **off** until you set `BANKR_WEBHOOK_URL`.

### WebSocket services added
- `wscrypto` — Binance 1m klines (crypto)
- `wsequities` — Polygon/Massive stocks AM.* (1m aggregates)

**Note**: Polygon.io rebranded as Massive.com, but the 'wss://socket.polygon.io/stocks' endpoint and 'AM.<TICKER>' subscribe pattern remain supported.


## v0.5 additions (this patch)
- Momentum **badges** in dashboard header (AIXBT score)
- Stocks **trades & quotes** WS worker (T.* and Q.*)
- **Observability stack**: Prometheus (scrapes API + Pushgateway), Pushgateway, Grafana on :3000

### Prometheus & Grafana
- Prometheus UI: http://localhost:9090  (scrapes API /metrics and Pushgateway)
- Grafana UI: http://localhost:3000 (admin/admin) → Add Prometheus datasource at `http://prometheus:9090`
- Example metrics: `api_requests_total`, `signals_total`, `ingest_bars_total`


## v0.8 additions
- **Alertmanager receivers** scaffolded (email, Telegram, Teams webhook) with env expansion. Default route still `devnull`; switch to a receiver to enable notifications.
- **WS lag alert**: `WSNoMessages` fires if `ws_messages_total` does not increase for 2 minutes.
- **Grafana WebSocket Health** dashboard added (messages/sec by stream/type).

### Enable Alertmanager notifications
1) Set env in `.env` (e.g., `AM_SMTP_SMARTHOST`, `AM_EMAIL_TO`, `AM_SMTP_FROM`, etc.).
2) Edit `observability/alertmanager.yml` → change `route.receiver: devnull` to `email` (or `telegram` / `teams`).
3) Restart: `docker compose restart alertmanager` (or `docker compose up -d --build`).
