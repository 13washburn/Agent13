## 1.8.0 — Screener Prime (2026-03-01)
- Main UI refocus on Stage 2/4 Screener; Bankr moved to Toolbox (read-only activity)
- Realtime consensus across providers. Kaiko set as primary for crypto, with CoinAPI + CCXT as backups
- 2% breakout/breakdown triggers with confirmations (Volume, OBV, Pressure, AVWAP S/R, TTM Squeeze)
- SSE event `squeeze` + distinct audio cue
- **Stage 4 breakdown tone enabled by default**
- **Provider Health Pill** with live SSE updates (status, p50 latency, error rate, last update)
