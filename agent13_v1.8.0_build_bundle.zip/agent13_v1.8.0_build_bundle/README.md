# Agent 13 — v1.8.0 (Screener Prime)

This bundle contains the **build scripts**, **Docker Compose**, and **drop‑in components** to ship the
v1.8.0 release with:

- Bankr moved into Toolbox (no main card)
- Stage 2 / Stage 4 Screener as main UI
- Realtime consensus aggregator (Kaiko primary; CoinAPI + CCXT fallback; SIP + Polygon for equities)
- 2% triggers + confirmations (Volume, OBV, Buy/Sell Pressure, S/R via Anchored VWAP, TTM Squeeze)
- SSE streams for signals and provider health
- **Audio cues**: Stage 2 breakout + **Squeeze fires** (both stages) + **Stage 4 breakdown tone enabled by default**
- **Provider Health Pill** (click to expand details)

> Note: These files assume your monorepo layout from v1.7.x. If paths differ, adjust imports accordingly.

## Quick start

1. Merge `apps/api/**` and `apps/web/**` files into your repo.
2. Set environment variables in `.env` (see below).
3. Build & run:

```bash
pnpm install
pnpm run build && pnpm run test

# Build fresh images
make release    # or: ./scripts/build.sh

# Launch
docker compose -f ops/compose.yml up -d

# Print image digests
make digests    # or: ./scripts/print_digests.sh
```

Artifacts written to `dist/release/`:
- `agent13-api:1.8.0` image
- `agent13-web:1.8.0` image
- `agent13_v1.8.0_digests.txt`

## .env template

```env
POLYGON_API_KEY=your_polygon_key
SIP_VENDOR_URL=
KAIKO_API_KEY=your_kaiko_key
COINAPI_KEY=your_coinapi_key
CCXT_EXCHANGES=binance,coinbase,kraken,okx,bybit

AGG_PRIMARY=kaiko
AGG_WEIGHTS='{"equities":{"sip":0.60,"polygon":0.40},"crypto":{"kaiko":0.60,"coinapi":0.25,"ccxt":0.15}}'

MIN_PRICE=2
MIN_MEDIAN_DVOL=250000
```

## What’s included here
- `apps/api/src/health/providerHealth.ts` — rolling stats per provider
- `apps/api/src/routes/health.ts` — REST + SSE endpoints for health
- `apps/web/src/components/ProviderHealthPill.tsx` — pill UI with popover
- `apps/web/src/features/screener/ScreenerView.tsx` — SSE + audio (breakout/squeeze/breakdown enabled)
- `ops/compose.yml` — simple docker compose
- `Makefile`, `scripts/*` — reproducible build + digest print

## Notes
- This is a **full build** workflow; you still integrate components into your repo’s codebase.
- Image digests are produced **locally** after you build; this bundle includes scripts to output them.
