import { useEffect, useRef, useState } from 'react';
import ProviderHealthPill from '@/components/ProviderHealthPill';

type Signal = {
  symbol: string;
  name?: string;
  assetClass: 'stock' | 'crypto';
  stage: 2 | 4;
  signalType: 'breakout' | 'breakdown';
  score: number;
  timestamp: string;
  price: number;
  basis?: string;
};

export default function ScreenerView() {
  const [tab, setTab] = useState<2 | 4>(2);
  const [signals, setSignals] = useState<Signal[]>([]);
  const [topCount, setTopCount] = useState<3 | 10>(3);
  const lastSqueezeRef = useRef<Record<string, number>>({});
  const ENABLE_BREAKDOWN_TONE = true; // enabled by default as requested

  useEffect(() => {
    const es = new EventSource(`/api/stream/signals?stage=${tab}`);
    es.onmessage = (e) => {
      const sig: Signal = JSON.parse(e.data);
      setSignals(prev => mergeAndRank([sig, ...prev]));
      if (sig.stage === 2 && sig.signalType === 'breakout') playBreakout();
      if (ENABLE_BREAKDOWN_TONE && sig.stage === 4 && sig.signalType === 'breakdown') playBreakdown();
    };
    es.addEventListener('squeeze', (e: MessageEvent) => {
      const ev = JSON.parse(e.data); // { symbol, stage, timestamp, timeframe }
      if (shouldChimeSqueeze(ev.symbol)) playSqueeze(); // fires for both stages
    });
    es.onerror = () => es.close();
    return () => es.close();
  }, [tab]);

  const top = signals.slice(0, topCount);

  return (
    <div className="h-full flex flex-col">
      <header className="mb-3 flex items-center justify-between gap-3">
        <div className="flex gap-2">
          <TabButton active={tab===2} onClick={() => setTab(2)} label="Stage 2 Breakouts" />
          <TabButton active={tab===4} onClick={() => setTab(4)} label="Stage 4 Breakdowns" />
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs text-muted-foreground">Top</span>
          <select className="text-xs rounded-lg bg-muted px-2 py-1" value={topCount} onChange={(e)=>setTopCount(Number(e.target.value) as 3|10)}>
            <option value={3}>3</option>
            <option value={10}>10</option>
          </select>
          <ProviderHealthPill />
        </div>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
        {top.map((s, i) => (
          <SignalCard key={`${s.symbol}-${s.timestamp}-${i}`} signal={s} index={i} />
        ))}
      </section>

      <div className="flex-1 min-h-0 border rounded-2xl overflow-hidden">
        <SignalTable signals={signals} />
      </div>
    </div>
  );

  function mergeAndRank(items: Signal[]) {
    const uniq = new Map<string, Signal>();
    for (const it of items) {
      const k = `${it.symbol}-${it.stage}`;
      if (!uniq.has(k) || new Date(it.timestamp) > new Date(uniq.get(k)!.timestamp)) {
        uniq.set(k, it);
      }
    }
    return Array.from(uniq.values()).sort((a,b) => (b.score - a.score) || (+new Date(b.timestamp) - +new Date(a.timestamp)));
  }

  function shouldChimeSqueeze(sym: string) {
    const now = Date.now();
    const last = lastSqueezeRef.current[sym] ?? 0;
    if (now - last < 30_000) return false;
    lastSqueezeRef.current[sym] = now;
    return true;
  }
}

// simple tab/button & audio helpers (inline for brevity)
function TabButton({active, onClick, label}:{active:boolean; onClick:()=>void; label:string}){
  return (
    <button onClick={onClick} className={`px-3 py-1.5 rounded-xl text-sm ${active? 'bg-muted' : 'hover:bg-muted/60'}`}>{label}</button>
  );
}

function playBreakout() {
  const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
  const o = ctx.createOscillator(), g = ctx.createGain();
  o.type = 'triangle'; o.frequency.value = 880; // A5
  g.gain.setValueAtTime(0.0001, ctx.currentTime);
  g.gain.exponentialRampToValueAtTime(0.06, ctx.currentTime + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.20);
  o.connect(g).connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.22);
}

function playSqueeze() {
  const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
  const o = ctx.createOscillator(), g = ctx.createGain();
  o.type = 'sine'; o.frequency.value = 1319.0; // E6
  g.gain.setValueAtTime(0.0001, ctx.currentTime);
  g.gain.linearRampToValueAtTime(0.04, ctx.currentTime + 0.015);
  g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.18);
  o.connect(g).connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.20);
}

function playBreakdown() {
  const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
  const o = ctx.createOscillator(), g = ctx.createGain();
  o.type = 'sawtooth'; o.frequency.value = 392.0; // G4
  g.gain.setValueAtTime(0.0001, ctx.currentTime);
  g.gain.linearRampToValueAtTime(0.035, ctx.currentTime + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.20);
  o.connect(g).connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.22);
}

// Placeholder components (assumed existing in your codebase)
function SignalCard({signal, index}:{signal: any; index:number}){ return <div className="border rounded-2xl p-3">#{index+1} {signal.symbol} · {signal.score}</div>; }
function SignalTable({signals}:{signals:any[]}){ return <div className="p-3 text-sm">{signals.length} signals</div>; }
