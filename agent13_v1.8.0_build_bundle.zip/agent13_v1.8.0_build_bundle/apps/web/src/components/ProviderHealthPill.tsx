import { useEffect, useRef, useState } from 'react';

type Item = {
  key: 'sip'|'polygon'|'kaiko'|'coinapi'|'ccxt';
  status: 'green'|'amber'|'red';
  connected: boolean;
  lastOkAgeMs: number | null;
  p50LatencyMs: number | null;
  errRatePct: number;
  sampleCount: number;
  lastErrTs: number | null;
};

type Snap = { ts: number; items: Item[] };

const LABELS: Record<Item['key'], string> = {
  sip: 'SIP', polygon: 'Polygon', kaiko: 'Kaiko', coinapi: 'CoinAPI', ccxt: 'CCXT Mesh',
};

const dot = (s: Item['status']) => s === 'green' ? 'bg-emerald-500' : s === 'amber' ? 'bg-amber-500' : 'bg-rose-500';

export default function ProviderHealthPill() {
  const [snap, setSnap] = useState<Snap | null>(null);
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const es = new EventSource('/api/stream/health');
    es.onmessage = (e) => setSnap(JSON.parse(e.data));
    es.onerror = () => es.close();
    return () => es.close();
  }, []);

  useEffect(() => {
    const onDoc = (e: MouseEvent) => { if (open && ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, [open]);

  const items = snap?.items ?? [];
  const worst = rankWorst(items);

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen(v => !v)}
        className="inline-flex items-center gap-2 rounded-full px-3 py-1.5 bg-muted hover:bg-muted/70 transition"
        aria-label="Provider health"
        title="Provider health"
      >
        <span className={`inline-block w-2.5 h-2.5 rounded-full ${dot(worst.status)}`} />
        <span className="text-xs">Providers</span>
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-[360px] border rounded-2xl bg-popover shadow-lg p-3 z-50">
          <div className="text-sm font-semibold mb-2">Provider Health</div>
          <div className="grid grid-cols-1 gap-2">
            {items.map(it => (
              <div key={it.key} className="flex items-center justify-between rounded-xl px-2 py-2 bg-muted/40">
                <div className="flex items-center gap-2">
                  <span className={`inline-block w-2.5 h-2.5 rounded-full ${dot(it.status)}`} />
                  <span className="text-sm">{LABELS[it.key]}</span>
                  {!it.connected && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-rose-500/10 text-rose-500">disconnected</span>
                  )}
                </div>
                <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
                  <span>{it.p50LatencyMs != null ? `${it.p50LatencyMs} ms` : '—'}</span>
                  <span>err {it.errRatePct?.toFixed(1)}%</span>
                  <span>{it.lastOkAgeMs != null ? `${Math.round(it.lastOkAgeMs/1000)}s` : '—'} ago</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function rankWorst(items: Item[]) {
  // sort by severity red > amber > green, then by lastOkAge
  const rank = { red: 3, amber: 2, green: 1 } as const;
  if (!items.length) return { status: 'red' as const };
  return items.slice().sort((a, b) => (rank[b.status] - rank[a.status]) || ((a.lastOkAgeMs ?? 0) - (b.lastOkAgeMs ?? 0)))[0];
}
