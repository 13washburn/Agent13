# Agent 13 — v1.6 (Full Stack)

**What’s new in v1.6**
- **Bankr REST MVP** wired in with: client, **/ops/bankr** routes, and optional **Stage‑2 trigger** (crypto). Disabled by default via env flags.
- **Small wins**: centralized **Bankr policy** endpoint, **Prometheus metrics** + **Grafana panel** for Bankr jobs, and a **Bankr Activity** drawer in the dashboard (last 5 jobs per symbol).

> Bankr Quick Start (Agent API/endpoints): https://docs.bankr.bot/getting-started/quick-start/  
> Bankr Docs (platform, CLI, skills): https://docs.bankr.bot/

## Quick start
```bash
cp .env.example .env   # set POLYGON_API_KEY for equities; set BANKR_* if using Bankr

docker compose up --build
```
- Dashboard → http://localhost:8501
- API → http://localhost:8000/docs
- Prometheus → http://localhost:9090
- Alertmanager → http://localhost:9093
- Grafana → http://localhost:3000 (admin/admin)

## v1.6 Env additions
```env
# Bankr integration (server-side)
BANKR_ENABLED=true
BANKR_DRYRUN=true          # false → live prompts allowed
BANKR_API_KEY=bk_********************************

# Bankr policy
BANKR_DEFAULT_BUY_USD=25
BANKR_MIN_CONF=2.0
BANKR_WHITELIST=BTC,ETH    # comma-separated bases allowed for auto actions
```

## Notes
- Polygon stocks WS follows auth → subscribe to `AM.*`, `T.*`, `Q.*`; quotes/trades power NBBO spark & mini tape.  
- Grafana dashboards are auto-provisioned on container start.
