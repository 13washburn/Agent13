import json, os, time
from typing import Optional
from .aixbt_client import AIXBT
_cache = { 'ts': 0, 'projects': [] }
DEFAULT_HINTS = { 'BTC':['bitcoin','btc'], 'ETH':['ethereum','eth'], 'SOL':['solana','sol'], 'ARB':['arbitrum','arb'], 'OP':['optimism','op'] }
class MomentumService:
    def __init__(self, client: Optional[AIXBT] = None):
        self.client = client or AIXBT()
        self.hints = dict(DEFAULT_HINTS)
        path = os.getenv('AIXBT_SYMBOL_MAP','').strip()
        if path and os.path.exists(path):
            try:
                with open(path,'r',encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        for k,v in data.items():
                            if isinstance(v,list): self.hints[k.upper()] = v
            except Exception: pass
    def _refresh(self):
        now = time.time()
        if now - _cache['ts'] < 300 and _cache['projects']: return
        try:
            page=1; allp=[]
            while True:
                resp = self.client.projects(page=page, limit=50)
                data = resp.get('data') or resp.get('projects') or []
                if not data: break
                allp += data
                pg = resp.get('pagination') or {}
                if not pg.get('hasMore'): break
                page += 1
            _cache['ts']=now; _cache['projects']=allp
        except Exception: pass
    def map_symbol(self, symbol: str):
        self._refresh(); base = symbol.split('/')[0].upper()
        aliases = [base.lower()] + [a.lower() for a in self.hints.get(base, [])]
        best=None; score=0
        for p in _cache['projects']:
            name=(p.get('name') or p.get('title') or p.get('symbol') or '').lower()
            s=sum(len(a) for a in aliases if a in name)
            if s>score: best,score=p,s
        return best
    def momentum_score(self, project_id: str):
        try:
            m=self.client.momentum(project_id)
            if isinstance(m, dict):
                d=m.get('data',{})
                if isinstance(d, dict):
                    s=d.get('score') or d.get('momentum')
                    if isinstance(s,(int,float)): return float(s)
                vals=m.get('values',[])
                if isinstance(vals,list) and vals:
                    last=vals[-1]
                    if isinstance(last, dict):
                        for k in ('score','momentum','value'):
                            if isinstance(last.get(k),(int,float)): return float(last[k])
        except Exception: return None
        return None
    def momentum_series(self, project_id: str, days: int = 7):
        try:
            m = self.client.momentum(project_id)
            vals = m.get('values', []) if isinstance(m, dict) else []
            out=[]
            for v in vals[-days:]:
                if isinstance(v, dict):
                    ts=v.get('timestamp') or v.get('ts'); sc=v.get('score') or v.get('momentum') or v.get('value')
                    if ts and isinstance(sc,(int,float)):
                        out.append({'ts': ts, 'score': float(sc)})
            return out
        except Exception: return []
    @staticmethod
    def bucket(score: float | None):
        if score is None: return 'low'
        if score >= 70: return 'strong'
        if score >= 40: return 'medium'
        return 'low'
