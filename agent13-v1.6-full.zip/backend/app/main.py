from fastapi import FastAPI
from fastapi.responses import PlainTextResponse, Response
import os, requests
from sqlalchemy import select, func, text as sa_text
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
from .db.database import SessionLocal
from .db.models import Signal, Bar
from .momentum.momentum_service import MomentumService
from .routers import bankr_ops

app = FastAPI(title="Agent 13 API", version="1.6")
app.include_router(bankr_ops.router)
MOM = MomentumService()

@app.get('/metrics')
def metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

@app.get('/health')
def health():
    return {"ok": True}

@app.get('/runbook', response_class=PlainTextResponse)
def runbook():
    return "Agent 13 Runbook — Dashboard → Help → Runbook"

@app.get('/ws/health')
def ws_health():
    prom = os.getenv('PROM_URL','http://prometheus:9090')
    q = 'sum by (stream)(increase(ws_messages_total[120s]))'
    try:
        r = requests.get(f"{prom}/api/v1/query", params={'query': q}, timeout=2)
        data = r.json().get('data',{}).get('result',[])
        out = { i['metric'].get('stream','unknown'): float(i['value'][1]) for i in data }
        status = { s: ('ok' if v>5 else ('partial' if v>0 else 'stall')) for s,v in out.items() }
        return {"ok": True, "status": status}
    except Exception:
        return {"ok": False, "status": {"binance":"idle","polygon_ws_am":"idle","polygon_ws_tq":"idle"}}

@app.get('/signals/recent')
def signals_recent(symbol: str, limit: int = 12):
    db = SessionLocal();
    try:
        rows = db.execute(select(Signal).where(Signal.symbol==symbol).order_by(Signal.ts.desc()).limit(limit)).scalars().all()
        return [{ 'symbol': r.symbol, 'ts': r.ts.isoformat(), 'stage': r.stage, 'confidence': r.confidence } for r in rows]
    finally:
        db.close()

@app.get('/signals/feed')
def signals_feed(limit: int = 20):
    db = SessionLocal();
    try:
        rows = db.execute(select(Signal).order_by(Signal.ts.desc()).limit(limit)).scalars().all()
        return [{ 'symbol': r.symbol, 'ts': r.ts.isoformat(), 'stage': r.stage, 'confidence': r.confidence } for r in rows]
    finally:
        db.close()

@app.get('/momentum')
def momentum(symbol: str):
    pj = MOM.map_symbol(symbol)
    out = { 'symbol': symbol, 'project': pj, 'score': None, 'bucket': 'low' }
    if pj and pj.get('id'):
        sc = MOM.momentum_score(pj['id'])
        out['score'] = sc
        out['bucket'] = MOM.bucket(sc)
    return out

@app.get('/momentum/trend')
def momentum_trend(symbol: str, days: int = 7):
    pj = MOM.map_symbol(symbol)
    if pj and pj.get('id'):
        series = MOM.momentum_series(pj['id'], days=days)
        return { 'symbol': symbol, 'project': pj, 'series': series }
    return { 'symbol': symbol, 'project': None, 'series': [] }

@app.get('/last_updated')
def last_updated(symbol: str):
    db = SessionLocal();
    try:
        ts = db.execute(select(func.max(Bar.ts)).where(Bar.symbol==symbol)).scalar()
        return { 'symbol': symbol, 'ts': ts.isoformat() if ts else None }
    finally:
        db.close()

@app.get('/stocks/nbbo/spark')
def nbbo_spark(ticker: str, lookback_min: int = 60):
    db = SessionLocal()
    try:
        q = sa_text("""
            SELECT ts,
                   (ask + bid)/2.0 AS mid,
                   CASE WHEN (ask + bid) > 0 THEN (ask - bid)/((ask + bid)/2.0)*10000 ELSE NULL END AS spread_bps
            FROM stock_quotes
            WHERE sym = :sym AND ts >= NOW() - (:mins || ' minutes')::interval
            ORDER BY ts ASC
        """)
        rows = db.execute(q, { 'sym': ticker.upper(), 'mins': lookback_min }).fetchall()
        out = []
        for ts, mid, bps in rows:
            out.append({ 'ts': ts.isoformat(), 'mid': float(mid) if mid is not None else None, 'spread_bps': float(bps) if bps is not None else None })
        return { 'ticker': ticker.upper(), 'rows': out }
    finally:
        db.close()

@app.get('/stocks/tape')
def stocks_tape(ticker: str, limit: int = 20):
    db = SessionLocal()
    try:
        rows = db.execute(sa_text("SELECT ts, price, size FROM stock_trades WHERE sym=:sym ORDER BY ts DESC LIMIT :lim"), {'sym': ticker.upper(), 'lim': limit}).fetchall()
        return {'ticker': ticker.upper(), 'rows': [{'ts': r[0].isoformat(), 'price': float(r[1] or 0), 'size': float(r[2] or 0)} for r in rows]}
    finally:
        db.close()
