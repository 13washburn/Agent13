from fastapi import APIRouter, HTTPException
import os, time
from sqlalchemy import text as sa_text
from ..db.database import SessionLocal
from ..integrations.bankr import BankrClient, BANKR_API_KEY
from prometheus_client import Counter

router = APIRouter(prefix="/ops/bankr", tags=["ops:bankr"])

SUBMIT = Counter('bankr_jobs_submitted_total', 'Bankr jobs submitted', ['source','mode','symbol'])
SETTLE = Counter('bankr_jobs_settled_total', 'Bankr jobs settled', ['status'])

@router.get('/ping')
def bankr_ping():
    enabled = os.getenv('BANKR_ENABLED','false').lower() == 'true'
    dryrun  = os.getenv('BANKR_DRYRUN','true').lower() == 'true'
    return {'enabled': enabled, 'dryrun': dryrun, 'has_key': bool(BANKR_API_KEY)}

@router.get('/policy')
def bankr_policy():
    return {
        'enabled': os.getenv('BANKR_ENABLED','false').lower()=='true',
        'dryrun': os.getenv('BANKR_DRYRUN','true').lower()=='true',
        'default_buy_usd': float(os.getenv('BANKR_DEFAULT_BUY_USD','25')),
        'min_conf': float(os.getenv('BANKR_MIN_CONF','2.0')),
        'whitelist': [s.strip().upper() for s in os.getenv('BANKR_WHITELIST','BTC,ETH').split(',') if s.strip()],
    }

@router.post('/prompt')
def bankr_prompt(payload: dict):
    enabled = os.getenv('BANKR_ENABLED','false').lower() == 'true'
    if not enabled: raise HTTPException(400, 'Bankr disabled')
    if not BANKR_API_KEY: raise HTTPException(401, 'Missing API key')
    prompt = (payload or {}).get('prompt')
    source = (payload or {}).get('source','api')
    mode = 'dryrun' if os.getenv('BANKR_DRYRUN','true').lower()=='true' else 'live'
    if not prompt: raise HTTPException(400, 'prompt required')
    SUBMIT.labels(source=source, mode=mode, symbol=(payload or {}).get('symbol','NA')).inc()
    cli = BankrClient()
    db = SessionLocal()
    try:
        job = cli.post_prompt(prompt)
        jid = job.get('id') or job.get('jobId') or job.get('job_id')
        db.execute(sa_text("INSERT INTO bankr_jobs(symbol,prompt,job_id,status,result,source,mode) VALUES (:s,:p,:j,:st,:r,:src,:m)"),
                   dict(s=(payload or {}).get('symbol'), p=prompt, j=jid, st=job.get('status'), r=json_dumps(job), src=source, m=mode))
        db.commit()
        return job
    except Exception as e:
        raise HTTPException(502, f'Bankr error: {e}')
    finally:
        db.close()

@router.post('/execute')
def bankr_execute(payload: dict):
    # Convenience endpoint used by worker to ensure logging/metrics regardless of dryrun
    enabled = os.getenv('BANKR_ENABLED','false').lower() == 'true'
    if not enabled: raise HTTPException(400, 'Bankr disabled')
    if not BANKR_API_KEY: raise HTTPException(401, 'Missing API key')
    prompt = (payload or {}).get('prompt')
    symbol = (payload or {}).get('symbol')
    source = (payload or {}).get('source','api')
    mode = (payload or {}).get('mode','live')
    if not prompt: raise HTTPException(400, 'prompt required')
    SUBMIT.labels(source=source, mode=mode, symbol=(symbol or 'NA')).inc()
    cli = BankrClient()
    db = SessionLocal()
    try:
        job = cli.post_prompt(prompt)
        jid = job.get('id') or job.get('jobId') or job.get('job_id')
        db.execute(sa_text("INSERT INTO bankr_jobs(symbol,prompt,job_id,status,result,source,mode) VALUES (:s,:p,:j,:st,:r,:src,:m)"),
                   dict(s=symbol, p=prompt, j=jid, st=job.get('status'), r=json_dumps(job), src=source, m=mode))
        db.commit()
        return job
    except Exception as e:
        raise HTTPException(502, f'Bankr error: {e}')
    finally:
        db.close()

@router.get('/job/{job_id}')
def bankr_job(job_id: str):
    enabled = os.getenv('BANKR_ENABLED','false').lower() == 'true'
    if not enabled: raise HTTPException(400, 'Bankr disabled')
    if not BANKR_API_KEY: raise HTTPException(401, 'Missing API key')
    cli = BankrClient()
    try:
        res = cli.get_job(job_id)
        status = (res.get('status') or '').lower()
        if status in ('done','completed','success'):
            SETTLE.labels(status='success').inc()
        elif status in ('error','failed'):
            SETTLE.labels(status='error').inc()
        return res
    except Exception as e:
        SETTLE.labels(status='error').inc()
        raise HTTPException(502, f'Bankr error: {e}')

@router.get('/jobs')
def bankr_jobs(symbol: str | None = None, limit: int = 5):
    db = SessionLocal()
    try:
        if symbol:
            rows = db.execute(sa_text("SELECT created_at, symbol, prompt, job_id, status FROM bankr_jobs WHERE symbol=:s ORDER BY created_at DESC LIMIT :l"), {'s': symbol, 'l': limit}).fetchall()
        else:
            rows = db.execute(sa_text("SELECT created_at, symbol, prompt, job_id, status FROM bankr_jobs ORDER BY created_at DESC LIMIT :l"), {'l': limit}).fetchall()
        return [{ 'ts': r[0].isoformat(), 'symbol': r[1], 'prompt': r[2], 'job_id': r[3], 'status': r[4]} for r in rows]
    finally:
        db.close()

# tiny helper
import json as _json

def json_dumps(x):
    try:
        return _json.dumps(x)
    except Exception:
        return _json.dumps({'raw': str(x)})
