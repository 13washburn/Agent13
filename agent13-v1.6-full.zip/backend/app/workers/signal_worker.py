import time, os, pandas as pd, requests
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert
from ..db.database import SessionLocal
from ..db.models import Bar, Signal
from ..detection.indicators import add_obv_ad
from ..detection.stage_analysis import label_stages
from ..momentum.momentum_service import MomentumService

API_BASE = os.getenv('API_BASE','http://api:8000')
BANKR_ENABLED = os.getenv('BANKR_ENABLED','false').lower() == 'true'
BANKR_DRYRUN  = os.getenv('BANKR_DRYRUN','true').lower() == 'true'
BANKR_MIN_CONF = float(os.getenv('BANKR_MIN_CONF','2.0'))
BANKR_DEFAULT_BUY_USD = float(os.getenv('BANKR_DEFAULT_BUY_USD','25'))
WL = [s.strip().upper() for s in os.getenv('BANKR_WHITELIST','BTC,ETH').split(',') if s.strip()]

MOM = MomentumService()

def fetch_symbols(db):
    return db.execute(select(Bar.symbol).distinct()).scalars().all()

while True:
    db = SessionLocal()
    try:
        for sym in fetch_symbols(db):
            rows = db.execute(select(Bar).where(Bar.symbol==sym).order_by(Bar.ts.asc())).scalars().all()
            if not rows: continue
            df = pd.DataFrame([{ 'timestamp': r.ts, 'open': r.open, 'high': r.high, 'low': r.low, 'close': r.close, 'volume': r.volume } for r in rows]).set_index('timestamp')
            df = add_obv_ad(df); lab = label_stages(df)
            lab['confidence'] = lab['rvol10'].clip(lower=0, upper=3).fillna(0)
            pj = MOM.map_symbol(sym)
            if pj and pj.get('id'):
                sc = MOM.momentum_score(pj['id'])
                if sc is not None:
                    lab['confidence'] = (lab['confidence'] + min(sc/100.0, 0.5)).clip(0, 3.5)
            lab = lab.tail(5)
            for ts, row in lab.iterrows():
                stmt = insert(Signal).values(symbol=sym, ts=ts, stage=row['stage'], confidence=float(row.get('confidence',0) or 0), rvol10=float(row.get('rvol10',0) or 0), obv_slope=float(row.get('obv_slope',0) or 0), ad_slope=float(row.get('ad_slope',0) or 0), extras=None).on_conflict_do_nothing(index_elements=['symbol','ts','stage'])
                db.execute(stmt)
                # Optional: Bankr auto action (crypto only)
                try:
                    if BANKR_ENABLED and not BANKR_DRYRUN:
                        base = (sym.split('/')[0] if '/' in sym else '').upper()
                        if base and base in WL and row.get('stage') == 'Stage 2' and float(row.get('confidence') or 0) >= BANKR_MIN_CONF:
                            prompt = f"Buy ${BANKR_DEFAULT_BUY_USD:.0f} of {base} on Base"
                            # Use API route so it logs & emits metrics
                            requests.post(f"{API_BASE}/ops/bankr/execute", json={
                                'symbol': sym,
                                'prompt': prompt,
                                'source': 'worker',
                                'mode': 'live'
                            }, timeout=10)
                except Exception:
                    pass
        db.commit()
    except Exception:
        db.rollback()
    finally:
        db.close()
    time.sleep(30)
