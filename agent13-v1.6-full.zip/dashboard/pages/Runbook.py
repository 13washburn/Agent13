import os, requests, streamlit as st
API_BASE = os.getenv('API_BASE','http://localhost:8000')
st.set_page_config(page_title='Agent 13 — Runbook', layout='wide')
st.title('Agent 13 — Runbook')
try:
    md = requests.get(f"{API_BASE}/runbook", timeout=5).text
except Exception as e:
    md = f"Runbook fetch failed: {e}"
st.markdown(md)
st.download_button('Download Runbook (MD)', data=md, file_name='Agent13-Runbook.md')
